package com.maverickbank.service;

import org.springframework.stereotype.Service;

@Service
public class AuthService {
}
