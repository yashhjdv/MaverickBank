# 🏦 Maverick Bank Frontend

A modern, feature-rich Angular-based frontend application for comprehensive banking operations. This application provides a complete digital banking solution with role-based access for customers, employees, and administrators.

## 📋 Project Description

Maverick Bank Frontend is a sophisticated web application that serves as the user interface for a full-stack banking system. It offers secure account management, loan processing, money transfers, transaction monitoring, and comprehensive reporting capabilities. The application is built with Angular 20 and follows modern web development practices with a focus on security, usability, and responsive design.

## 🛠️ Tech Stack Used

### Frontend Framework & Core
- **Angular 20.0.0** - Modern TypeScript-based framework
- **TypeScript 5.8.2** - Type-safe programming language
- **RxJS 7.8.0** - Reactive programming with observables
- **Zone.js 0.15.0** - Change detection and async operations

### UI & Styling
- **Custom CSS** - Modern, responsive design system
- **Google Fonts (Inter)** - Typography
- **CSS Grid & Flexbox** - Layout systems
- **CSS Variables** - Theme management
- **Responsive Design** - Mobile-first approach

### Development & Testing
- **Angular CLI 20.0.5** - Project tooling and build system
- **Jasmine 5.7.0** - Testing framework
- **Karma 6.4.0** - Test runner
- **TypeScript Compiler** - Code compilation

### Build & Deployment
- **Angular Build System** - Optimized production builds
- **Proxy Configuration** - Development API routing
- **Environment Configuration** - Multi-environment support

## 🏗️ Folder Structure

```
maverick-bank-frontend/
├── src/
│   ├── app/
│   │   ├── components/              # All Angular UI components
│   │   │   ├── home/               # Landing page component
│   │   │   ├── login/              # User authentication
│   │   │   ├── register/           # New user registration
│   │   │   ├── dashboard/          # Role-based main dashboard
│   │   │   ├── account-management/ # Account operations & details
│   │   │   ├── account-approval/   # Employee account approval
│   │   │   ├── customer-account-request/ # New account requests
│   │   │   ├── employee-account-management/ # Employee account tools
│   │   │   ├── loan-management/    # Loan applications & management
│   │   │   ├── loan-type-management/ # Admin loan type configuration
│   │   │   ├── money-transfer/     # Fund transfer operations
│   │   │   ├── transactions/       # Transaction history & details
│   │   │   ├── beneficiaries/      # Payee management
│   │   │   ├── customer-reports/   # Customer reporting tools
│   │   │   ├── customer-reports-page/ # Customer report dashboard
│   │   │   ├── employee-reports/   # Employee reporting tools
│   │   │   ├── employee-reports-page/ # Employee report dashboard
│   │   │   ├── user-management/    # Admin user management
│   │   │   └── notifications/      # Global notification system
│   │   ├── services/               # API communication & business logic
│   │   │   ├── auth.service.ts     # Authentication & JWT management
│   │   │   ├── account-management.service.ts # Account operations
│   │   │   ├── account-request.service.ts # Account request handling
│   │   │   ├── loan.service.ts     # Loan operations
│   │   │   ├── loan-type.service.ts # Loan type management
│   │   │   ├── money-transfer.service.ts # Transfer operations
│   │   │   ├── transaction.service.ts # Transaction handling
│   │   │   ├── beneficiary.service.ts # Beneficiary management
│   │   │   ├── report.service.ts   # Report generation
│   │   │   ├── user-management.service.ts # User operations
│   │   │   ├── notification.service.ts # Notification system
│   │   │   ├── loading.service.ts  # Loading state management
│   │   │   ├── navigation.service.ts # Navigation utilities
│   │   │   └── bank.service.ts     # Bank-specific operations
│   │   ├── guards/                 # Route protection
│   │   │   ├── auth.guard.ts       # Authentication verification
│   │   │   └── role.guard.ts       # Role-based access control
│   │   ├── interceptors/           # HTTP request/response handling
│   │   │   ├── auth.interceptor.ts # JWT token attachment
│   │   │   └── error.interceptor.ts # Global error handling
│   │   ├── shared/                 # Shared utilities & resources
│   │   │   └── logo.ts            # Logo management
│   │   ├── app-routing-module.ts   # Application routing configuration
│   │   ├── app-module.ts          # Main application module
│   │   └── app.ts                 # Root component
│   ├── assets/                     # Static resources
│   │   └── images/                # Image assets
│   │       └── maverick-logo.png  # Application logo
│   ├── styles.css                  # Global application styles
│   ├── index.html                  # Application entry point
│   └── main.ts                     # Application bootstrap
├── public/                         # Public static files
│   ├── favicon.ico                # Browser favicon
│   └── images/                    # Public images
├── proxy.conf.json                # Development proxy configuration
├── angular.json                   # Angular workspace configuration
├── package.json                   # Dependencies & scripts
├── tsconfig.json                  # TypeScript configuration
└── README.md                      # Project documentation
```

## 🧩 Component Breakdown

### **Core Components**

#### **1. Home Component (`/home`)**
- **Purpose**: Landing page with modern design and navigation
- **Features**: 
  - Professional banking-themed hero section
  - Feature highlights and service overview
  - Call-to-action buttons for registration/login
  - Responsive navigation with animated elements
- **Connected Services**: `NavigationService`
- **Key Functionality**: User onboarding and initial engagement

#### **2. Login Component (`/login`)**
- **Purpose**: Secure user authentication
- **Features**:
  - JWT-based authentication with form validation
  - Role-based redirect after successful login
  - Error handling with user-friendly messages
  - Remember me functionality
- **Connected Services**: `AuthService`, `NotificationService`
- **Security**: Token management, input sanitization

#### **3. Register Component (`/register`)**
- **Purpose**: New user registration with comprehensive data collection
- **Features**:
  - Multi-step form with validation
  - Real-time field validation
  - Secure password requirements
  - Identity verification fields (Aadhar, PAN)
- **Connected Services**: `AuthService`, `NotificationService`
- **Validation**: Email format, phone number, government ID validation

#### **4. Dashboard Component (`/dashboard`)**
- **Purpose**: Role-based main interface after login
- **Features**:
  - **Customer Dashboard**: Account overview, recent transactions, quick actions
  - **Employee Dashboard**: Pending approvals, customer management tools
  - **Admin Dashboard**: System overview, user management, reports
  - Dynamic content based on user role
  - Modern card-based layout with statistics
- **Connected Services**: `AuthService`, `AccountManagementService`, `NavigationService`
- **Key Functionality**: Central hub for all banking operations

### **Account Management Components**

#### **5. Account Management Component (`/accounts`)**
- **Purpose**: Comprehensive account operations and viewing
- **Features**:
  - Multi-tab interface (Account Details, Transactions, Statements)
  - Real-time balance updates
  - Transaction filtering and search
  - Account status management
  - Downloadable statements
- **Connected Services**: `AccountManagementService`, `TransactionService`
- **Key Functionality**: Complete account lifecycle management

#### **6. Customer Account Request Component (`/request-account`)**
- **Purpose**: New account application for customers
- **Features**:
  - Multi-step account opening process
  - Document upload capability
  - Account type selection (Savings, Current, etc.)
  - Branch selection with IFSC code integration
  - Real-time application status tracking
- **Connected Services**: `AccountRequestService`, `BankService`
- **Workflow**: Form submission → Employee review → Approval/Rejection

#### **7. Employee Account Management Component (`/employee-accounts`)**
- **Purpose**: Employee tools for account operations
- **Features**:
  - Account approval workflow
  - Customer account search and filtering
  - Account modification capabilities
  - Bulk operations for efficiency
  - Audit trail maintenance
- **Connected Services**: `AccountManagementService`, `UserManagementService`
- **Access Control**: Employee and Admin roles only

### **Loan Management Components**

#### **8. Loan Management Component (`/loan-management`)**
- **Purpose**: Complete loan lifecycle management
- **Features**:
  - Loan application processing
  - EMI calculation with interactive sliders
  - Loan status tracking and updates
  - Document management for loan processing
  - Payment history and upcoming EMI alerts
- **Connected Services**: `LoanService`, `AccountManagementService`
- **Key Functionality**: End-to-end loan processing workflow

#### **9. Loan Type Management Component (`/loan-type-management`)**
- **Purpose**: Administrative loan product configuration
- **Features**:
  - Create and modify loan products
  - Interest rate management
  - Tenure and amount limit configuration
  - Loan eligibility criteria setup
  - Product activation/deactivation
- **Connected Services**: `LoanTypeService`
- **Access Control**: Admin role only

### **Financial Transaction Components**

#### **10. Money Transfer Component (`/money-transfer`)**
- **Purpose**: Secure fund transfer operations
- **Features**:
  - NEFT/RTGS/IMPS transfer options
  - Beneficiary management integration
  - Transaction limits and validation
  - Multi-factor authentication for high-value transfers
  - Transfer scheduling and recurring payments
- **Connected Services**: `MoneyTransferService`, `BeneficiaryService`
- **Security**: Multi-layer validation, fraud detection

#### **11. Transactions Component (`/transactions`)**
- **Purpose**: Transaction history and management
- **Features**:
  - Comprehensive transaction listing with filters
  - Date range selection and search functionality
  - Transaction categorization and tagging
  - Export capabilities (PDF, Excel)
  - Dispute resolution initiation
- **Connected Services**: `TransactionService`, `ReportService`
- **Analytics**: Spending patterns, category analysis

#### **12. Beneficiaries Component (`/beneficiaries`)**
- **Purpose**: Payee management for transfers
- **Features**:
  - Add/edit/delete beneficiaries
  - Beneficiary verification workflow
  - Favorite beneficiaries for quick access
  - Bulk import/export functionality
  - Transaction history per beneficiary
- **Connected Services**: `BeneficiaryService`, `MoneyTransferService`
- **Security**: Account verification, fraud prevention

### **Reporting Components**

#### **13. Customer Reports Page Component (`/customer-reports`)**
- **Purpose**: Customer-focused reporting and analytics
- **Features**:
  - Account statements with customizable date ranges
  - Transaction analysis and spending insights
  - Tax computation assistance
  - Financial goal tracking
  - Downloadable reports in multiple formats
- **Connected Services**: `ReportService`, `AccountManagementService`
- **Analytics**: Personal financial insights, trends

#### **14. Employee Reports Page Component (`/employee-reports`)**
- **Purpose**: Employee and admin reporting tools
- **Features**:
  - Customer portfolio analysis
  - Account opening statistics
  - Loan portfolio performance
  - Branch-wise performance metrics
  - Compliance and audit reports
- **Connected Services**: `ReportService`, `UserManagementService`
- **Access Control**: Employee and Admin roles

### **Administrative Components**

#### **15. User Management Component (`/user-management`)**
- **Purpose**: Administrative user operations
- **Features**:
  - User creation and profile management
  - Role assignment and permission management
  - Account linking and unlinking
  - User activity monitoring
  - Bulk user operations
- **Connected Services**: `UserManagementService`, `AuthService`
- **Access Control**: Admin role only

#### **16. Account Approval Component (`/account-approval`)**
- **Purpose**: Employee workflow for account approvals
- **Features**:
  - Pending request queue management
  - Document verification interface
  - Approval/rejection workflow with comments
  - Risk assessment tools
  - Batch processing capabilities
- **Connected Services**: `AccountRequestService`, `AccountManagementService`
- **Workflow**: Review → Verify → Approve/Reject → Notify

#### **17. Notifications Component (`/notifications`)**
- **Purpose**: Global notification system
- **Features**:
  - Real-time notifications for account activities
  - System alerts and maintenance notices
  - Personalized financial recommendations
  - Push notification preferences
  - Notification history and management
- **Connected Services**: `NotificationService`
- **Types**: Success, Error, Warning, Info notifications

## 🛣️ Routing Explanation

### **Route Structure**
The application uses Angular's powerful routing system with sophisticated guard mechanisms for security and user experience.

### **Public Routes (No Authentication Required)**
```typescript
{ path: '', component: HomeComponent }
{ path: 'home', component: HomeComponent }
{ path: 'login', component: LoginComponent }
{ path: 'register', component: RegisterComponent }
```

### **Protected Routes (Authentication Required)**
All protected routes use `AuthGuard` to ensure user authentication:

```typescript
{ path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] }
{ path: 'accounts', component: AccountManagementComponent, canActivate: [AuthGuard] }
{ path: 'loan-management', component: LoanManagementComponent, canActivate: [AuthGuard] }
```

### **Role-Based Protected Routes**
Advanced routes using both `AuthGuard` and `RoleGuard` for role-based access:

#### **Customer-Only Routes**
```typescript
{ 
  path: 'request-account', 
  component: CustomerAccountRequestComponent, 
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['CUSTOMER'] }
}
{ 
  path: 'customer-reports', 
  component: CustomerReportsPageComponent, 
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['CUSTOMER'] }
}
```

#### **Employee & Admin Routes**
```typescript
{ 
  path: 'employee-accounts', 
  component: EmployeeAccountManagementComponent, 
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['EMPLOYEE', 'ADMIN'] }
}
{ 
  path: 'employee-reports', 
  component: EmployeeReportsPageComponent, 
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['EMPLOYEE', 'ADMIN'] }
}
```

#### **Admin-Only Routes**
```typescript
{ 
  path: 'admin', 
  component: DashboardComponent, 
  canActivate: [AuthGuard, RoleGuard], 
  data: { roles: ['ADMIN'] } 
}
{ 
  path: 'loan-type-management', 
  component: LoanTypeManagementComponent, 
  canActivate: [AuthGuard, RoleGuard],
  data: { roles: ['ADMIN'] }
}
```

### **Guard Implementation**

#### **AuthGuard Protection**
- Verifies JWT token presence and validity
- Automatically redirects to login if token is expired
- Loads user profile if token exists but user data is missing
- Maintains session continuity across browser refreshes

#### **RoleGuard Protection**
- Checks user roles against required route roles
- Provides granular access control
- Shows appropriate error messages for unauthorized access
- Redirects to dashboard if access is denied

### **Wildcard Route**
```typescript
{ path: '**', redirectTo: '/login' }
```
Catches all undefined routes and redirects to login for security.

## 🏪 State Management

The application uses a **service-based state management pattern** rather than a complex state store, optimized for banking application requirements:

### **Service-Based Architecture**
- **Centralized Services**: Each domain (Auth, Accounts, Loans) has dedicated services
- **RxJS Observables**: Reactive state management with BehaviorSubjects
- **Local State**: Component-level state for UI-specific data
- **Session Persistence**: Critical data stored in localStorage with encryption

### **Key State Management Services**

#### **AuthService State**
- User authentication status
- JWT token management
- User profile and role information
- Session persistence and restoration

#### **AccountManagementService State**
- Current user accounts
- Selected account information
- Account transaction cache
- Real-time balance updates

#### **NotificationService State**
- Global notification queue
- User preference settings
- Notification history

### **Benefits of This Approach**
- **Simplicity**: Easy to understand and maintain
- **Performance**: Minimal overhead compared to complex state stores
- **Security**: Banking-specific security considerations built-in
- **Flexibility**: Easy to extend for new features

## 🔧 Services

### **Authentication & Security Services**

#### **AuthService (`auth.service.ts`)**
- **Purpose**: Complete authentication lifecycle management
- **Key Methods**:
  - `login(credentials)`: JWT-based user authentication
  - `register(userData)`: New user registration
  - `logout()`: Secure session termination
  - `getCurrentUser()`: Active user profile retrieval
  - `isTokenExpired()`: Token validity verification
  - `loadUserProfile()`: User data restoration from token
- **Security Features**: 
  - Automatic token refresh
  - Secure token storage
  - Session timeout handling
  - Role-based access verification

### **Account Management Services**

#### **AccountManagementService (`account-management.service.ts`)**
- **Purpose**: Core account operations and data management
- **Key Methods**:
  - `getUserAccounts()`: Retrieve user's accounts
  - `getAccountDetails(accountId)`: Detailed account information
  - `updateAccountStatus()`: Account activation/deactivation
  - `getAccountTransactions()`: Transaction history retrieval
  - `generateStatement()`: Account statement generation
- **Features**: Real-time balance updates, transaction caching, multi-account support

#### **AccountRequestService (`account-request.service.ts`)**
- **Purpose**: New account application workflow management
- **Key Methods**:
  - `submitAccountRequest()`: New account application submission
  - `getPendingRequests()`: Employee pending approval queue
  - `approveRequest()`: Account approval processing
  - `rejectRequest()`: Account rejection with comments
  - `getRequestStatus()`: Application status tracking
- **Workflow Integration**: Complete request-to-approval pipeline

### **Financial Services**

#### **LoanService (`loan.service.ts`)**
- **Purpose**: Comprehensive loan management operations
- **Key Methods**:
  - `applyForLoan()`: Loan application submission
  - `calculateEMI()`: Real-time EMI calculations
  - `getUserLoans()`: User loan portfolio
  - `updateLoanStatus()`: Employee loan processing
  - `getLoanDetails()`: Detailed loan information
- **Features**: EMI calculator, loan eligibility check, document management

#### **LoanTypeService (`loan-type.service.ts`)**
- **Purpose**: Administrative loan product management
- **Key Methods**:
  - `createLoanType()`: New loan product creation
  - `updateLoanType()`: Loan product modification
  - `getAllLoanTypes()`: Available loan products
  - `toggleLoanTypeStatus()`: Product activation/deactivation
- **Admin Features**: Interest rate management, eligibility criteria setup

#### **MoneyTransferService (`money-transfer.service.ts`)**
- **Purpose**: Secure fund transfer operations
- **Key Methods**:
  - `initiateTransfer()`: Fund transfer initiation
  - `verifyBeneficiary()`: Beneficiary account verification
  - `getTransferLimits()`: User transfer limits
  - `scheduleTransfer()`: Future-dated transfer scheduling
  - `getTransferHistory()`: Transfer transaction history
- **Security**: Multi-factor authentication, fraud detection, limit enforcement

#### **TransactionService (`transaction.service.ts`)**
- **Purpose**: Transaction processing and history management
- **Key Methods**:
  - `getTransactionHistory()`: Comprehensive transaction retrieval
  - `searchTransactions()`: Advanced transaction filtering
  - `categorizeTransaction()`: Transaction categorization
  - `exportTransactions()`: Data export functionality
  - `disputeTransaction()`: Transaction dispute initiation
- **Analytics**: Spending analysis, transaction patterns, reporting

### **Support Services**

#### **BeneficiaryService (`beneficiary.service.ts`)**
- **Purpose**: Payee management for transfers
- **Key Methods**:
  - `addBeneficiary()`: New beneficiary registration
  - `verifyBeneficiary()`: Account verification process
  - `updateBeneficiary()`: Beneficiary information updates
  - `deleteBeneficiary()`: Beneficiary removal
  - `getFavoriteBeneficiaries()`: Quick access payees
- **Features**: Bulk operations, verification workflow, favorite management

#### **ReportService (`report.service.ts`)**
- **Purpose**: Report generation and analytics
- **Key Methods**:
  - `generateAccountStatement()`: Detailed account statements
  - `getSpendingAnalysis()`: Personal spending insights
  - `generateTaxReport()`: Tax computation assistance
  - `getPortfolioAnalysis()`: Investment portfolio analysis
  - `exportReport()`: Multi-format report export
- **Formats**: PDF, Excel, CSV export options

#### **UserManagementService (`user-management.service.ts`)**
- **Purpose**: Administrative user operations
- **Key Methods**:
  - `createUser()`: New user account creation
  - `updateUserProfile()`: User information updates
  - `assignRole()`: Role management operations
  - `deactivateUser()`: User account deactivation
  - `getUserActivity()`: Activity monitoring and logs
- **Admin Features**: Bulk operations, role management, audit trails

### **Utility Services**

#### **NotificationService (`notification.service.ts`)**
- **Purpose**: Global notification and messaging system
- **Key Methods**:
  - `showSuccess()`: Success message display
  - `showError()`: Error message handling
  - `showWarning()`: Warning notifications
  - `showInfo()`: Informational messages
  - `clearNotifications()`: Notification queue management
- **Features**: Auto-dismiss, persistent notifications, user preferences

#### **LoadingService (`loading.service.ts`)**
- **Purpose**: Application loading state management
- **Key Methods**:
  - `setLoading()`: Global loading state control
  - `isLoading()`: Loading state observation
  - `startOperation()`: Operation-specific loading
  - `completeOperation()`: Loading completion handling
- **UX Features**: Prevents multiple simultaneous requests, loading indicators

#### **NavigationService (`navigation.service.ts`)**
- **Purpose**: Navigation utilities and route management
- **Key Methods**:
  - `navigateToRoute()`: Programmatic navigation
  - `goBack()`: Browser history navigation
  - `getCurrentRoute()`: Active route information
  - `setReturnUrl()`: Post-login navigation
- **Features**: Breadcrumb management, deep linking support

### **HTTP Communication Pattern**
All services follow a consistent pattern:
- **Base URL Configuration**: Centralized API endpoint management
- **Error Handling**: Consistent error response processing
- **Loading States**: Integrated loading state management
- **Retry Logic**: Automatic retry for failed requests
- **Caching**: Strategic response caching for performance

## 🔐 Authentication Flow

### **Complete Authentication Workflow**

#### **1. Initial User Authentication**
```typescript
// Login Process
login(credentials) → Backend Validation → JWT Token Generation → User Profile Loading
```

**Steps**:
1. User submits login credentials
2. `AuthService` sends credentials to backend `/api/auth/login`
3. Backend validates credentials and returns JWT token
4. Token is stored securely in localStorage
5. User profile is loaded and stored in `BehaviorSubject`
6. User is redirected to role-appropriate dashboard

#### **2. JWT Token Management**
- **Token Storage**: Secure localStorage with encryption considerations
- **Token Structure**: Contains user ID, roles, and expiration timestamp
- **Token Validation**: Automatic expiration checking on each route navigation
- **Token Refresh**: Automatic refresh before expiration (when implemented)

#### **3. Session Persistence**
```typescript
// Session Restoration on App Load
constructor() {
  const token = localStorage.getItem('auth_token');
  const savedUser = localStorage.getItem('user');
  
  if (token && !this.isTokenExpired(token)) {
    if (savedUser) {
      this.userSubject.next(JSON.parse(savedUser));
    } else {
      this.loadUserProfile(); // Fetch from API
    }
  }
}
```

#### **4. Route Protection Implementation**

**AuthGuard Protection Flow**:
```typescript
canActivate() → Check Token → Validate Expiration → Load User Profile → Allow/Deny Access
```

**RoleGuard Protection Flow**:
```typescript
canActivate() → Get User Roles → Check Required Roles → Allow/Deny Access → Show Error if Denied
```

#### **5. Automatic Token Interception**
```typescript
// AuthInterceptor automatically attaches tokens
intercept(request, next) {
  const token = this.authService.getToken();
  if (token) {
    request = request.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }
  return next.handle(request);
}
```

### **Security Features**

#### **Token Security**
- JWT tokens contain minimal sensitive information
- Automatic logout on token expiration
- Secure transmission over HTTPS
- Client-side token validation

#### **Session Management**
- Configurable session timeout
- Activity-based session renewal
- Secure logout with token invalidation
- Multi-tab session synchronization

#### **Role-Based Access Control (RBAC)**
- Granular permission system
- Route-level protection
- Component-level feature toggles
- API endpoint protection

#### **Fraud Prevention**
- Session monitoring for unusual activity
- Failed login attempt tracking
- IP address validation (backend)
- Multi-factor authentication (planned)

## 📱 Responsive Design

### **Mobile-First Design Philosophy**
The application follows a mobile-first approach ensuring optimal experience across all devices.

### **CSS Grid & Flexbox Layout System**
```css
/* Responsive Grid System */
.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

/* Flexible Navigation */
.nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
```

### **Breakpoint System**
```css
/* Mobile First Breakpoints */
@media (max-width: 768px) {
  .dashboard-sidebar { transform: translateX(-100%); }
  .main-content { padding: 1rem; }
}

@media (min-width: 769px) and (max-width: 1024px) {
  .dashboard-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (min-width: 1025px) {
  .dashboard-grid { grid-template-columns: repeat(3, 1fr); }
}
```

### **Responsive Features**

#### **Navigation Adaptation**
- **Desktop**: Full horizontal navigation with dropdowns
- **Tablet**: Collapsible navigation with icons
- **Mobile**: Hamburger menu with slide-out drawer

#### **Component Responsiveness**
- **Cards**: Fluid width with minimum/maximum constraints
- **Tables**: Horizontal scroll on mobile, stacked layout
- **Forms**: Single-column layout on mobile, multi-column on desktop
- **Buttons**: Full-width on mobile, inline on desktop

#### **Typography Scaling**
```css
/* Responsive Typography */
h1 { font-size: clamp(1.5rem, 4vw, 2.5rem); }
.card-title { font-size: clamp(1rem, 2.5vw, 1.25rem); }
```

### **Touch-Friendly Interface**
- **Button Sizing**: Minimum 44px tap targets
- **Spacing**: Adequate spacing between interactive elements
- **Gestures**: Swipe navigation for mobile users
- **Accessibility**: High contrast, readable fonts, keyboard navigation

### **Performance Optimizations**
- **Lazy Loading**: Images and non-critical components
- **CSS Optimization**: Minimal critical CSS, async loading
- **Bundle Splitting**: Route-based code splitting
- **Caching**: Strategic component and data caching

## 🌐 API Integration

### **Backend Communication Architecture**

#### **Base API Configuration**
```typescript
private baseUrl = 'http://localhost:9090/api';
```

#### **Proxy Configuration for Development**
```json
{
  "/api/*": {
    "target": "http://localhost:9090",
    "secure": false,
    "changeOrigin": true,
    "logLevel": "debug"
  }
}
```

### **API Communication Patterns**

#### **Standardized HTTP Methods**
- **GET**: Data retrieval (accounts, transactions, reports)
- **POST**: Data creation (new accounts, transactions, loans)
- **PUT**: Data updates (profile updates, account modifications)
- **DELETE**: Data removal (beneficiaries, loan applications)

#### **Request/Response Structure**

**Sample Authentication API Call**:
```typescript
login(credentials: LoginRequest): Observable<AuthResponse> {
  return this.http.post<AuthResponse>(`${this.baseUrl}/auth/login`, credentials)
    .pipe(
      map(response => {
        localStorage.setItem(this.tokenKey, response.token);
        this.loadUserProfile();
        return response;
      }),
      catchError(this.handleError)
    );
}
```

**Sample Account Data API Call**:
```typescript
getUserAccounts(): Observable<Account[]> {
  return this.http.get<Account[]>(`${this.baseUrl}/accounts`)
    .pipe(
      map(accounts => {
        this.accountsSubject.next(accounts);
        return accounts;
      }),
      catchError(this.handleError)
    );
}
```

### **Sample API Response Structures**

#### **Authentication Response**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "name": "John Doe",
    "email": "john@example.com",
    "roles": [{"name": "CUSTOMER"}]
  }
}
```

#### **Account Information Response**
```json
{
  "id": 1001,
  "accountNumber": "ACC001001",
  "accountType": "SAVINGS",
  "accountName": "John Doe Savings",
  "balance": 25000.00,
  "ifscCode": "MVK0001",
  "branchName": "Main Branch",
  "isActive": true,
  "openedDate": "2024-01-15"
}
```

#### **Transaction History Response**
```json
{
  "transactions": [
    {
      "id": 5001,
      "type": "CREDIT",
      "amount": 5000.00,
      "description": "Salary Credit",
      "date": "2024-07-15T10:30:00Z",
      "balance": 25000.00,
      "reference": "SAL/JUL/2024"
    }
  ],
  "pagination": {
    "page": 1,
    "size": 20,
    "totalElements": 150,
    "totalPages": 8
  }
}
```

### **Error Handling Strategy**

#### **Global Error Interceptor**
```typescript
export class ErrorInterceptor implements HttpInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          this.authService.logout();
          this.router.navigate(['/login']);
        }
        
        this.notificationService.error(this.getErrorMessage(error));
        return throwError(error);
      })
    );
  }
}
```

#### **Error Response Handling**
- **401 Unauthorized**: Automatic logout and redirect to login
- **403 Forbidden**: Permission denied notification
- **404 Not Found**: Resource not found handling
- **500 Server Error**: Generic server error notification
- **Network Errors**: Offline/connectivity issue handling

### **Loading State Management**
```typescript
// Service-level loading states
private loadingSubject = new BehaviorSubject<boolean>(false);
public loading$ = this.loadingSubject.asObservable();

performOperation(): Observable<any> {
  this.loadingSubject.next(true);
  return this.http.post(url, data).pipe(
    finalize(() => this.loadingSubject.next(false))
  );
}
```

### **Caching Strategy**
- **User Profile**: Cached until logout
- **Account Data**: 5-minute cache with refresh option
- **Static Data**: Long-term caching (loan types, branches)
- **Transactions**: Smart caching with pagination

## 🚀 How to Run the Project

### **Prerequisites**
Before running the Maverick Bank Frontend, ensure you have the following installed:

- **Node.js**: Version 18.x or later
- **npm**: Version 9.x or later (comes with Node.js)
- **Angular CLI**: Version 20.x
- **Git**: For version control
- **VS Code**: Recommended IDE with Angular extensions

### **System Requirements**
- **Operating System**: Windows 10/11, macOS 10.15+, or Linux
- **RAM**: Minimum 8GB (16GB recommended for development)
- **Storage**: At least 2GB free space
- **Browser**: Chrome 90+, Firefox 88+, Safari 14+, or Edge 90+

### **Installation Steps**

#### **1. Clone the Repository**
```bash
git clone <repository-url>
cd maverick-bank-frontend
```

#### **2. Install Dependencies**
```bash
npm install
```

This will install all required packages including:
- Angular framework and CLI tools
- TypeScript compiler
- Development dependencies
- Testing frameworks

#### **3. Environment Configuration**
Verify the proxy configuration in `proxy.conf.json`:
```json
{
  "/api/*": {
    "target": "http://localhost:9090",
    "secure": false,
    "changeOrigin": true
  }
}
```

#### **4. Start the Development Server**
```bash
npm start
# or alternatively
ng serve --proxy-config proxy.conf.json
```

#### **5. Access the Application**
- Open your browser and navigate to: `http://localhost:4200`
- The application will automatically reload when you make changes to the source files

### **Development Commands**

#### **Start Development Server**
```bash
npm start                    # Start with proxy configuration
ng serve                     # Start without proxy
ng serve --port 4201        # Start on different port
ng serve --open             # Start and open browser automatically
```

#### **Build Commands**
```bash
npm run build               # Production build
ng build --configuration development    # Development build
ng build --watch           # Build and watch for changes
```

#### **Testing Commands**
```bash
npm test                    # Run unit tests
ng test                     # Run tests with coverage
ng test --watch=false      # Single test run
ng test --code-coverage    # Generate coverage report
```

#### **Code Quality Commands**
```bash
ng lint                     # Run linting
ng lint --fix              # Auto-fix linting issues
```

### **Backend Requirements**
This frontend application requires the Maverick Bank Backend to be running:

1. **Backend Server**: Must be running on `http://localhost:9090`
2. **Database**: Backend should have proper database connectivity
3. **API Endpoints**: All required endpoints should be available

### **Environment Variables** (if applicable)
Create a `.env` file in the root directory if environment-specific configurations are needed:
```env
API_BASE_URL=http://localhost:9090/api
ENVIRONMENT=development
```

### **Common Development Issues & Solutions**

#### **Port Already in Use**
```bash
# If port 4200 is occupied
ng serve --port 4201
```

#### **Node Modules Issues**
```bash
# Clear node modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### **Angular CLI Issues**
```bash
# Update Angular CLI globally
npm install -g @angular/cli@latest
```

### **Development Workflow**
1. Start backend server on port 9090
2. Start frontend development server: `npm start`
3. Access application at `http://localhost:4200`
4. Make changes to source files
5. View changes automatically in browser
6. Run tests: `npm test`
7. Build for production: `npm run build`

## 📸 Screenshots

*Note: Screenshots will be added to showcase the application's user interface and functionality.*

### **Planned Screenshots**

#### **1. Landing Page**
- Hero section with modern banking theme
- Navigation and call-to-action buttons
- Feature highlights and services overview

#### **2. Authentication Pages**
- Login page with form validation
- Registration page with multi-step process
- Password reset functionality

#### **3. Customer Dashboard**
- Account overview cards
- Recent transaction summary
- Quick action buttons
- Financial insights widgets

#### **4. Account Management**
- Account details interface
- Transaction history with filtering
- Statement generation options
- Account settings panel

#### **5. Loan Management**
- Loan application form
- EMI calculator interface
- Loan status tracking
- Document upload section

#### **6. Money Transfer**
- Transfer form with beneficiary selection
- Transaction confirmation screen
- Transfer history interface
- Beneficiary management panel

#### **7. Employee Dashboard**
- Pending approval queue
- Customer management tools
- Account approval workflow
- Performance metrics

#### **8. Admin Dashboard**
- System overview statistics
- User management interface
- Loan type configuration
- Comprehensive reporting tools

#### **9. Mobile Responsive Views**
- Mobile navigation drawer
- Responsive card layouts
- Touch-friendly interfaces
- Mobile-optimized forms

#### **10. Reports and Analytics**
- Interactive charts and graphs
- Downloadable report formats
- Financial analysis dashboards
- Export functionality

*Screenshots will demonstrate the application's modern UI, responsive design, and comprehensive banking functionality across different user roles and devices.*

## 🔮 Future Improvements

### **Immediate Enhancements (Next Release)**

#### **1. UPI Integration**
- **QR Code Generation**: Dynamic QR codes for payments
- **UPI Payment Gateway**: Integration with major UPI providers
- **Contact-based Payments**: Pay using mobile numbers
- **Bill Splitting**: Shared expense management
- **Merchant Payments**: Business transaction support

#### **2. Enhanced Notification System**
- **Real-time Push Notifications**: WebSocket-based instant alerts
- **Email Notifications**: Transaction confirmations and statements
- **SMS Integration**: OTP and critical alerts
- **In-app Notification Center**: Comprehensive message management
- **Notification Preferences**: Granular control over alert types

#### **3. Advanced Security Features**
- **Two-Factor Authentication (2FA)**: SMS and app-based authentication
- **Biometric Authentication**: Fingerprint and face recognition
- **Transaction PIN**: Additional security for high-value transactions
- **Device Registration**: Trusted device management
- **Session Management**: Enhanced security monitoring

### **Medium-term Features (6-12 months)**

#### **4. Investment Management**
- **Mutual Fund Integration**: SIP and lump-sum investments
- **Stock Trading**: Basic equity trading functionality
- **Portfolio Analytics**: Investment performance tracking
- **Risk Assessment**: Investor profiling and recommendations
- **Goal-based Investing**: Systematic investment planning

#### **5. Advanced Analytics & AI**
- **Spending Insights**: AI-powered financial behavior analysis
- **Budget Management**: Automated budget creation and tracking
- **Fraud Detection**: Machine learning-based anomaly detection
- **Personalized Recommendations**: Financial product suggestions
- **Predictive Analytics**: Cash flow forecasting

#### **6. Enhanced Admin Features**
- **Advanced Reporting Dashboard**: Real-time business intelligence
- **Audit Trail Management**: Comprehensive activity logging
- **Bulk Operations Interface**: Mass data processing capabilities
- **Workflow Automation**: Approval process automation
- **Compliance Monitoring**: Regulatory requirement tracking

### **Long-term Vision (1-2 years)**

#### **7. Multi-channel Banking**
- **Voice Banking**: Voice command integration
- **Chatbot Support**: AI-powered customer service
- **Video Banking**: Remote banking assistance
- **Social Media Integration**: Social payment features
- **IoT Integration**: Connected device payments

#### **8. Blockchain Integration**
- **Cryptocurrency Support**: Digital currency transactions
- **Smart Contracts**: Automated loan and insurance processing
- **Decentralized Identity**: Blockchain-based KYC
- **Cross-border Payments**: International transfer optimization
- **Supply Chain Finance**: Trade finance solutions

#### **9. Open Banking Architecture**
- **Third-party Integrations**: Fintech service partnerships
- **API Marketplace**: Developer ecosystem
- **Account Aggregation**: Multi-bank view functionality
- **Financial Marketplace**: Integrated financial services
- **PFM Integration**: Personal finance management tools

### **Technical Improvements**

#### **10. Performance Optimization**
- **Progressive Web App (PWA)**: Offline functionality
- **Code Splitting**: Advanced lazy loading strategies
- **Caching Strategy**: Enhanced performance optimization
- **CDN Integration**: Global content delivery
- **Bundle Optimization**: Reduced application size

#### **11. Testing & Quality Assurance**
- **End-to-End Testing**: Comprehensive automation testing
- **Performance Testing**: Load and stress testing
- **Security Testing**: Vulnerability assessment
- **Accessibility Testing**: WCAG compliance
- **Cross-browser Testing**: Enhanced compatibility

#### **12. DevOps & Deployment**
- **CI/CD Pipeline**: Automated build and deployment
- **Containerization**: Docker-based deployment
- **Cloud Migration**: Scalable cloud infrastructure
- **Monitoring & Logging**: Application performance monitoring
- **Disaster Recovery**: Business continuity planning

### **User Experience Enhancements**

#### **13. Accessibility Improvements**
- **Screen Reader Support**: Enhanced accessibility
- **Keyboard Navigation**: Complete keyboard support
- **High Contrast Mode**: Visual accessibility options
- **Multi-language Support**: Localization capabilities
- **Voice Control**: Accessibility through voice commands

#### **14. Customization Features**
- **Themeable Interface**: User-selectable themes
- **Dashboard Customization**: Personalized layouts
- **Widget Library**: Modular dashboard components
- **Notification Preferences**: Granular control options
- **Language Preferences**: Multi-language support

### **Integration Roadmap**
- **Payment Gateway Expansion**: Multiple payment providers
- **Banking Partner APIs**: Inter-bank connectivity
- **Government Services**: Tax filing and compliance
- **Insurance Integration**: Comprehensive financial planning
- **Credit Bureau Integration**: Enhanced credit management

These improvements will be prioritized based on user feedback, business requirements, and technological advancements, ensuring Maverick Bank remains at the forefront of digital banking innovation.

## 👥 Credits

### **Development Team**

#### **Lead Developer**
- **Name**: [Your Name]
- **Role**: Full-Stack Developer
- **Responsibilities**: 
  - Frontend architecture and implementation
  - Backend API integration
  - UI/UX design and responsive development
  - Security implementation and testing

### **Technologies & Frameworks Used**

#### **Frontend Framework**
- **Angular 20.0.0** - Google's TypeScript-based web application framework
- **TypeScript 5.8.2** - Microsoft's typed superset of JavaScript
- **RxJS 7.8.0** - Reactive Extensions for JavaScript

#### **Development Tools**
- **Angular CLI 20.0.5** - Command-line interface for Angular development
- **Node.js** - JavaScript runtime environment
- **npm** - Package manager for JavaScript

#### **Testing Framework**
- **Jasmine 5.7.0** - Behavior-driven development framework
- **Karma 6.4.0** - Test runner for JavaScript

#### **Build & Development**
- **Webpack** - Module bundler (via Angular CLI)
- **TypeScript Compiler** - Code compilation and type checking

### **Design & UI Resources**

#### **Typography**
- **Google Fonts (Inter)** - Modern, clean typography
- **Font Awesome** - Icon library (if used)

#### **Design Inspiration**
- **Modern Banking Interfaces** - Contemporary fintech design patterns
- **Material Design Principles** - Google's design language
- **Apple Human Interface Guidelines** - iOS design standards

### **Third-Party Libraries & Services**

#### **CSS Frameworks & Utilities**
- **Custom CSS Grid** - Modern layout system
- **Flexbox** - Flexible layout model
- **CSS Variables** - Dynamic theming support

#### **Development Utilities**
- **Prettier** - Code formatting tool
- **ESLint** - JavaScript/TypeScript linting (if configured)

### **Learning Resources & Documentation**

#### **Official Documentation**
- **Angular Documentation** - https://angular.io/docs
- **TypeScript Handbook** - https://www.typescriptlang.org/docs/
- **RxJS Documentation** - https://rxjs.dev/guide/overview

#### **Community Resources**
- **Angular Community** - https://community.angular.io/
- **Stack Overflow** - Problem-solving and community support
- **GitHub** - Code repositories and open-source contributions

### **Special Acknowledgments**

#### **Banking Domain Expertise**
- Industry best practices for banking applications
- Security standards and compliance requirements
- User experience research in financial services

#### **Code Quality & Standards**
- **Clean Code Principles** - Robert C. Martin's coding standards
- **Angular Style Guide** - Official Angular coding conventions
- **TypeScript Best Practices** - Community-driven development patterns

### **Open Source Contributions**
This project leverages numerous open-source technologies and frameworks. We acknowledge and appreciate the contributions of the global developer community that makes modern web development possible.

#### **Package Dependencies**
All package dependencies and their respective licenses are detailed in `package.json` and `package-lock.json`. We respect and comply with all open-source licenses.

### **Feedback & Contributions**
We welcome feedback, suggestions, and contributions from the developer community. Please refer to the contribution guidelines in the repository for more information on how to participate in this project's development.

### **Contact Information**
For technical questions, feature requests, or collaboration opportunities:
- **Project Repository**: [GitHub Repository URL]
- **Email**: [contact-email@domain.com]
- **LinkedIn**: [LinkedIn Profile]

---
