import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, map } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> {
    return this.authService.user$.pipe(
      map(user => {
        if (!user) {
          this.router.navigate(['/']);
          return false;
        }

        const requiredRoles = route.data['roles'] as Array<string>;
        const userRole = user.roles[0]?.name || 'CUSTOMER';

        if (requiredRoles && requiredRoles.length > 0) {
          if (!requiredRoles.includes(userRole)) {
            this.notificationService.error(`Access denied. Required role: ${requiredRoles.join(' or ')}`);
            this.router.navigate(['/dashboard']);
            return false;
          }
        }

        return true;
      })
    );
  }
}