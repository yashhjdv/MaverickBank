import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Transaction {
  id: number;
  accountId: number;
  transactionType: 'CREDIT' | 'DEBIT';
  amount: number;
  description: string;
  toAccount?: string;
  fromAccount?: string;
  timestamp: Date;
  balance: number;
  status: 'COMPLETED' | 'PENDING' | 'FAILED';
  referenceNumber?: string;
}

export interface TransactionRequest {
  accountId: number;
  amount: number;
  description: string;
  toAccountId?: number;
  toAccountNumber?: string;
}

export interface TransactionFilter {
  type: 'all' | 'last10' | 'lastMonth' | 'dateRange';
  startDate?: string;
  endDate?: string;
}

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private apiUrl = 'http://localhost:9090/api/transactions';

  constructor(private http: HttpClient) {}

  // Get transactions
  getAccountTransactions(accountId: number, filter?: TransactionFilter): Observable<Transaction[]> {
    if (filter?.type === 'last10') {
      return this.http.get<Transaction[]>(`${this.apiUrl}/account/${accountId}/recent?limit=10`)
        .pipe(catchError(() => this.getMockTransactions(accountId)));
    } else if (filter?.type === 'lastMonth') {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      return this.getTransactionsByDateRange(accountId, firstDay.toISOString().split('T')[0], now.toISOString().split('T')[0]);
    } else if (filter?.type === 'dateRange' && filter.startDate && filter.endDate) {
      return this.getTransactionsByDateRange(accountId, filter.startDate, filter.endDate);
    } else {
      return this.http.get<Transaction[]>(`${this.apiUrl}/account/${accountId}`)
        .pipe(catchError(() => this.getMockTransactions(accountId)));
    }
  }

  getLastNTransactions(accountId: number, count: number): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.apiUrl}/account/${accountId}/recent?limit=${count}`)
      .pipe(catchError(() => this.getMockTransactions(accountId)));
  }

  getTransactionsByDateRange(accountId: number, startDate: string, endDate: string): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.apiUrl}/account/${accountId}/date-range?startDate=${startDate}&endDate=${endDate}`)
      .pipe(catchError(() => this.getMockTransactions(accountId)));
  }

  getUserRecentTransactions(userId: number, limit: number = 10): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.apiUrl}/user/${userId}/recent?limit=${limit}`)
      .pipe(catchError(() => this.getMockTransactions(1)));
  }

  // Transaction operations
  deposit(request: TransactionRequest): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.apiUrl}/deposit`, request)
      .pipe(catchError(() => this.getMockTransaction(request, 'CREDIT')));
  }

  withdraw(request: TransactionRequest): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.apiUrl}/withdraw`, request)
      .pipe(catchError(() => this.getMockTransaction(request, 'DEBIT')));
  }

  transfer(request: TransactionRequest): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.apiUrl}/transfer`, request)
      .pipe(catchError(() => this.getMockTransaction(request, 'DEBIT')));
  }

  // Get transaction details
  getTransactionById(transactionId: number): Observable<Transaction> {
    return this.http.get<Transaction>(`${this.apiUrl}/${transactionId}`)
      .pipe(catchError(() => this.getMockTransactionById(transactionId)));
  }

  // Generate transaction statement
  generateStatement(accountId: number, startDate: string, endDate: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/account/${accountId}/statement?startDate=${startDate}&endDate=${endDate}`)
      .pipe(catchError(() => of({ success: true, message: 'Statement generated successfully' })));
  }

  // Mock data methods
  private getMockTransactions(accountId: number): Observable<Transaction[]> {
    const mockTransactions: Transaction[] = [
      {
        id: 1,
        accountId: accountId,
        transactionType: 'CREDIT',
        amount: 1000.00,
        description: 'Initial Deposit',
        timestamp: new Date('2024-01-15T10:30:00'),
        balance: 26000.50,
        status: 'COMPLETED',
        referenceNumber: 'REF001'
      },
      {
        id: 2,
        accountId: accountId,
        transactionType: 'DEBIT',
        amount: 50.00,
        description: 'ATM Withdrawal',
        timestamp: new Date('2024-01-14T15:45:00'),
        balance: 25000.50,
        status: 'COMPLETED',
        referenceNumber: 'REF002'
      },
      {
        id: 3,
        accountId: accountId,
        transactionType: 'CREDIT',
        amount: 500.00,
        description: 'Salary Credit',
        timestamp: new Date('2024-01-13T09:00:00'),
        balance: 25050.50,
        status: 'COMPLETED',
        referenceNumber: 'REF003'
      }
    ];
    return of(mockTransactions);
  }

  private getMockTransaction(request: TransactionRequest, type: 'CREDIT' | 'DEBIT'): Observable<Transaction> {
    const transaction: Transaction = {
      id: Date.now(),
      accountId: request.accountId,
      transactionType: type,
      amount: request.amount,
      description: request.description,
      timestamp: new Date(),
      balance: 25000.50, // Mock balance
      status: 'COMPLETED',
      referenceNumber: 'REF' + Date.now(),
      toAccount: request.toAccountNumber
    };
    return of(transaction);
  }

  private getMockTransactionById(transactionId: number): Observable<Transaction> {
    const transaction: Transaction = {
      id: transactionId,
      accountId: 1,
      transactionType: 'CREDIT',
      amount: 1000.00,
      description: 'Mock Transaction',
      timestamp: new Date(),
      balance: 25000.50,
      status: 'COMPLETED',
      referenceNumber: 'REF' + transactionId
    };
    return of(transaction);
  }
}
