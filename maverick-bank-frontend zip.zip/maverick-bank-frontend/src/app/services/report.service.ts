import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Account {
  id: number;
  accountNumber: string;
  accountType: string;
  balance: number;
  status: string;
  userId: number;
  createdAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: number;
  accountId: number;
  transactionType: string;
  amount: number;
  description: string;
  timestamp: string;
  toAccountId?: number;
  fromAccountId?: number;
}

export interface Loan {
  id: number;
  userId: number;
  loanType: string;
  loanAmount: number;
  interestRate: number;
  tenure: number;
  status: string;
  appliedDate: string;
  approvedDate?: string;
}

export interface ReportSummary {
  totalAccounts: number;
  totalTransactions: number;
  totalLoans: number;
  totalBalance: number;
  activeAccounts: number;
  pendingLoans: number;
  approvedLoans: number;
}

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private baseUrl = 'http://localhost:8080/api/reports';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  private handleError(error: any): Observable<never> {
    console.error('ReportService Error:', error);
    return throwError(() => error);
  }

  // Get all accounts report
  getAllAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/accounts`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get all transactions report
  getAllTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.baseUrl}/transactions`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get all loans report
  getAllLoans(): Observable<Loan[]> {
    return this.http.get<Loan[]>(`${this.baseUrl}/loans`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get total balance across all accounts
  getTotalBalance(): Observable<number> {
    console.log('🔄 ReportService: Fetching total balance...');
    return this.http.get<number>(`${this.baseUrl}/total-balance`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get user-specific accounts
  getUserAccounts(userId: number): Observable<Account[]> {
    console.log(`🔄 ReportService: Fetching accounts for user ${userId}...`);
    return this.http.get<Account[]>(`${this.baseUrl}/user/${userId}/accounts`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get user-specific transactions
  getUserTransactions(userId: number): Observable<Transaction[]> {
    console.log(`🔄 ReportService: Fetching transactions for user ${userId}...`);
    return this.http.get<Transaction[]>(`${this.baseUrl}/user/${userId}/transactions`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get user-specific loans
  getUserLoans(userId: number): Observable<Loan[]> {
    console.log(`🔄 ReportService: Fetching loans for user ${userId}...`);
    return this.http.get<Loan[]>(`${this.baseUrl}/user/${userId}/loans`, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Get account statement for specific account
  getAccountStatement(accountId: number, startDate?: string, endDate?: string): Observable<Transaction[]> {
    console.log(`🔄 ReportService: Fetching account statement for account ${accountId}...`);
    let url = `${this.baseUrl}/account/${accountId}/statement`;
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    if (params.toString()) url += `?${params.toString()}`;
    
    return this.http.get<Transaction[]>(url, { 
      headers: this.getHeaders() 
    }).pipe(
      catchError(this.handleError)
    );
  }

  // Generate summary report (client-side aggregation)
  getReportSummary(): Observable<ReportSummary> {
    return new Observable<ReportSummary>(observer => {
      // Fetch all data in parallel
      Promise.all([
        this.getAllAccounts().toPromise(),
        this.getAllTransactions().toPromise(),
        this.getAllLoans().toPromise(),
        this.getTotalBalance().toPromise()
      ]).then(([accounts, transactions, loans, totalBalance]) => {
        const summary: ReportSummary = {
          totalAccounts: accounts?.length || 0,
          totalTransactions: transactions?.length || 0,
          totalLoans: loans?.length || 0,
          totalBalance: totalBalance || 0,
          activeAccounts: accounts?.filter(acc => acc.status === 'ACTIVE').length || 0,
          pendingLoans: loans?.filter(loan => loan.status === 'PENDING').length || 0,
          approvedLoans: loans?.filter(loan => loan.status === 'APPROVED').length || 0
        };
        observer.next(summary);
        observer.complete();
      }).catch(error => {
        observer.error(error);
      });
    });
  }

  // Export data as CSV (client-side)
  exportAccountsToCSV(): void {
    this.getAllAccounts().subscribe({
      next: (accounts) => {
        const csvContent = this.convertToCSV(accounts, [
          'id', 'accountNumber', 'accountType', 'balance', 'status', 'userId', 'createdAt'
        ]);
        this.downloadCSV(csvContent, 'accounts-report.csv');
      },
      error: (error) => {
        console.error('Error exporting accounts:', error);
      }
    });
  }

  exportTransactionsToCSV(): void {
    this.getAllTransactions().subscribe({
      next: (transactions) => {
        const csvContent = this.convertToCSV(transactions, [
          'id', 'accountId', 'transactionType', 'amount', 'description', 'timestamp', 'toAccountId', 'fromAccountId'
        ]);
        this.downloadCSV(csvContent, 'transactions-report.csv');
      },
      error: (error) => {
        console.error('Error exporting transactions:', error);
      }
    });
  }

  exportLoansToCSV(): void {
    this.getAllLoans().subscribe({
      next: (loans) => {
        const csvContent = this.convertToCSV(loans, [
          'id', 'userId', 'loanType', 'loanAmount', 'interestRate', 'tenure', 'status', 'appliedDate', 'approvedDate'
        ]);
        this.downloadCSV(csvContent, 'loans-report.csv');
      },
      error: (error) => {
        console.error('Error exporting loans:', error);
      }
    });
  }

  private convertToCSV(data: any[], columns: string[]): string {
    const header = columns.join(',');
    const rows = data.map(item => 
      columns.map(col => {
        const value = item[col];
        return value !== undefined && value !== null ? `"${value}"` : '';
      }).join(',')
    );
    return [header, ...rows].join('\n');
  }

  private downloadCSV(csvContent: string, filename: string): void {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
