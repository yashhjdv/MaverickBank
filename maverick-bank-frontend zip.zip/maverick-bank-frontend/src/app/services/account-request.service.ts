import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface AccountRequest {
  id: number;
  userId: number;
  customerName: string;
  email: string;
  phone: string;
  accountType: string;
  initialDeposit: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestDate: Date;
  reviewDate?: Date;
  reviewedBy?: string;
  comments?: string;
  documents: Document[];
}

export interface Document {
  id: number;
  name: string;
  type: string;
  url: string;
  verified: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AccountRequestService {
  private apiUrl = 'http://localhost:9090/api/accounts';

  constructor(private http: HttpClient) {}

  getAllPendingRequests(): Observable<AccountRequest[]> {
    return this.http.get<AccountRequest[]>(`${this.apiUrl}/requests/pending`).pipe(
      catchError(() => this.getMockPendingRequests())
    );
  }

  approveRequest(requestId: number, comments?: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/requests/${requestId}/approve`, { comments }).pipe(
      catchError(() => of({ success: true, message: 'Request approved successfully' }))
    );
  }

  rejectRequest(requestId: number, comments: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/requests/${requestId}/reject`, { comments }).pipe(
      catchError(() => of({ success: true, message: 'Request rejected successfully' }))
    );
  }

  getRequestById(requestId: number): Observable<AccountRequest> {
    return this.http.get<AccountRequest>(`${this.apiUrl}/requests/${requestId}`).pipe(
      catchError(() => this.getMockRequestById(requestId))
    );
  }

  private getMockPendingRequests(): Observable<AccountRequest[]> {
    const mockRequests: AccountRequest[] = [
      {
        id: 1,
        userId: 101,
        customerName: 'John Doe',
        email: 'john.doe@email.com',
        phone: '+91-9876543210',
        accountType: 'SAVINGS',
        initialDeposit: 25000,
        status: 'PENDING',
        requestDate: new Date('2024-01-15'),
        documents: [
          { id: 1, name: 'Aadhar Card', type: 'IDENTITY', url: '/docs/aadhar1.pdf', verified: true },
          { id: 2, name: 'PAN Card', type: 'IDENTITY', url: '/docs/pan1.pdf', verified: true },
          { id: 3, name: 'Income Certificate', type: 'INCOME', url: '/docs/income1.pdf', verified: false }
        ]
      },
      {
        id: 2,
        userId: 102,
        customerName: 'Sarah Smith',
        email: 'sarah.smith@email.com',
        phone: '+91-9876543211',
        accountType: 'CURRENT',
        initialDeposit: 50000,
        status: 'PENDING',
        requestDate: new Date('2024-01-16'),
        documents: [
          { id: 4, name: 'Passport', type: 'IDENTITY', url: '/docs/passport2.pdf', verified: true },
          { id: 5, name: 'Business Registration', type: 'BUSINESS', url: '/docs/business2.pdf', verified: true }
        ]
      },
      {
        id: 3,
        userId: 103,
        customerName: 'Mike Johnson',
        email: 'mike.johnson@email.com',
        phone: '+91-9876543212',
        accountType: 'SAVINGS',
        initialDeposit: 15000,
        status: 'PENDING',
        requestDate: new Date('2024-01-17'),
        documents: [
          { id: 6, name: 'Voter ID', type: 'IDENTITY', url: '/docs/voter3.pdf', verified: false },
          { id: 7, name: 'Salary Certificate', type: 'INCOME', url: '/docs/salary3.pdf', verified: true }
        ]
      }
    ];
    return of(mockRequests);
  }

  private getMockRequestById(requestId: number): Observable<AccountRequest> {
    return this.getMockPendingRequests().pipe(
      map(requests => requests.find(r => r.id === requestId)!)
    );
  }
}
