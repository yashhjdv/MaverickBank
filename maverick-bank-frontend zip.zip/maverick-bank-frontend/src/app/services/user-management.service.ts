import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export interface UserDto {
  id?: number;
  username: string;
  name: string;
  email: string;
  contactNumber: string;
  address: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  gender: string;
  roles: Role[];
  isActive?: boolean;
  createdDate?: string;
  lastLoginDate?: string;
}

export interface Role {
  id: number;
  name: string;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  name: string;
  email: string;
  contactNumber: string;
  address: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  gender: string;
  roleIds: number[];
}

export interface UpdateUserRequest {
  name: string;
  email: string;
  contactNumber: string;
  address: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  gender: string;
  roleIds: number[];
  isActive: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  private baseUrl = 'http://localhost:9090/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  // Get all users
  getAllUsers(): Observable<UserDto[]> {
    return this.http.get<UserDto[]>(`${this.baseUrl}/users`, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Get user by ID
  getUserById(id: number): Observable<UserDto> {
    return this.http.get<UserDto>(`${this.baseUrl}/users/${id}`, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Search users by criteria
  searchUsers(searchTerm: string): Observable<UserDto[]> {
    return this.http.get<UserDto[]>(`${this.baseUrl}/users/search?term=${searchTerm}`, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Create new user - updated to handle different user types
  createUser(userData: CreateUserRequest): Observable<UserDto> {
    // Check if creating employee or customer based on roleIds
    const hasEmployeeRole = userData.roleIds.includes(2); // EMPLOYEE role ID
    const hasAdminRole = userData.roleIds.includes(1); // ADMIN role ID
    
    // Convert to backend expected format
    const backendData = {
      username: userData.username,
      password: userData.password,
      name: userData.name,
      email: userData.email,
      contactNumber: userData.contactNumber,
      address: userData.address,
      dateOfBirth: userData.dateOfBirth,
      aadharNumber: userData.aadharNumber,
      panNumber: userData.panNumber,
      gender: userData.gender
    };

    if (hasEmployeeRole || hasAdminRole) {
      // Use employee registration endpoint for employees and admins
      return this.http.post<UserDto>(`${this.baseUrl}/auth/register-employee`, backendData, {
        headers: this.authService.getAuthHeaders()
      });
    } else {
      // Use regular registration for customers
      return this.http.post<UserDto>(`${this.baseUrl}/auth/register`, backendData, {
        headers: this.authService.getAuthHeaders()
      });
    }
  }

  // Update user
  updateUser(id: number, userData: UpdateUserRequest): Observable<UserDto> {
    return this.http.put<UserDto>(`${this.baseUrl}/users/${id}/profile`, userData, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Delete user - implement deactivate instead of delete
  deleteUser(id: number): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/users/${id}/deactivate`, {}, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Activate/Deactivate user
  toggleUserStatus(id: number): Observable<UserDto> {
    return this.http.post<UserDto>(`${this.baseUrl}/users/${id}/activate`, {}, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Reset user password
  resetUserPassword(id: number, newPassword: string): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/auth/change-password`, 
      { userId: id, newPassword: newPassword }, 
      { headers: this.authService.getAuthHeaders() }
    );
  }

  // Get all available roles - create a simple implementation since backend doesn't have this endpoint
  getAllRoles(): Observable<Role[]> {
    // Since backend doesn't have /roles endpoint, return hardcoded roles
    const roles: Role[] = [
      { id: 1, name: 'ADMIN' },
      { id: 2, name: 'EMPLOYEE' },
      { id: 3, name: 'CUSTOMER' }
    ];
    return new Observable(observer => {
      observer.next(roles);
      observer.complete();
    });
  }

  // Assign role to user
  assignRoleToUser(userId: number, roleId: number): Observable<void> {
    const roleName = this.getRoleNameById(roleId);
    return this.http.post<void>(`${this.baseUrl}/users/${userId}/roles/${roleName}`, {}, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Remove role from user
  removeRoleFromUser(userId: number, roleId: number): Observable<void> {
    const roleName = this.getRoleNameById(roleId);
    return this.http.delete<void>(`${this.baseUrl}/users/${userId}/roles/${roleName}`, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Helper method to get role name by ID
  private getRoleNameById(roleId: number): string {
    switch(roleId) {
      case 1: return 'ADMIN';
      case 2: return 'EMPLOYEE';
      case 3: return 'CUSTOMER';
      default: return 'CUSTOMER';
    }
  }

  // Get users by role
  getUsersByRole(roleName: string): Observable<UserDto[]> {
    return this.http.get<UserDto[]>(`${this.baseUrl}/users/role/${roleName}`, {
      headers: this.authService.getAuthHeaders()
    });
  }

  // Get user statistics - create a simple implementation
  getUserStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/users/statistics`, {
      headers: this.authService.getAuthHeaders()
    });
  }
}
