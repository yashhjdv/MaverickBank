import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface LoanType {
  id?: number;
  loanName: string;
  description: string;
  interestRate: number;
  maxAmount: number;
  maxTenureMonths: number; // in months
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

@Injectable({
  providedIn: 'root'
})
export class LoanTypeService {
  private baseUrl = 'http://localhost:9090/api/loan-types';

  constructor(private http: HttpClient) {}

  private getHttpOptions() {
    const token = localStorage.getItem('token');
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }

  // Get all active loan types (for customers)
  getActiveLoanTypes(): Observable<LoanType[]> {
    return this.http.get<LoanType[]>(this.baseUrl, this.getHttpOptions());
  }

  // Get all loan types including inactive ones (for admin)
  getAllLoanTypes(): Observable<LoanType[]> {
    return this.http.get<LoanType[]>(`${this.baseUrl}/all`, this.getHttpOptions());
  }

  // Get loan type by ID
  getLoanTypeById(id: number): Observable<LoanType> {
    return this.http.get<LoanType>(`${this.baseUrl}/${id}`, this.getHttpOptions());
  }

  // Create new loan type
  createLoanType(loanType: LoanType): Observable<LoanType> {
    return this.http.post<LoanType>(this.baseUrl, loanType, this.getHttpOptions());
  }

  // Update loan type
  updateLoanType(id: number, loanType: LoanType): Observable<LoanType> {
    return this.http.put<LoanType>(`${this.baseUrl}/${id}`, loanType, this.getHttpOptions());
  }

  // Delete (deactivate) loan type
  deleteLoanType(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, this.getHttpOptions());
  }
}
