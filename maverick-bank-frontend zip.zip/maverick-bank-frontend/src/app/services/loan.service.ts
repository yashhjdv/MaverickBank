import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface LoanType {
  id: number;
  name: string;
  description: string;
  interestRate: number;
  maxAmount: number;
  minAmount: number;
  maxTenure: number;
  minTenure: number;
  processingFee: number;
  isActive: boolean;
}

export interface Loan {
  id: number;
  userId: number;
  loanTypeId: number;
  loanType: LoanType;
  accountId: number;
  amount: number;
  tenure: number;
  interestRate: number;
  emiAmount: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'DISBURSED' | 'CLOSED';
  applicationDate: Date;
  approvalDate?: Date;
  disbursementDate?: Date;
  remarks?: string;
  employeeComments?: string;
}

export interface LoanApplicationRequest {
  userId: number;
  loanTypeId: number;
  accountId: number;
  amount: number;
  tenure: number;
  purpose: string;
  monthlyIncome: number;
  employmentType: string;
  documents?: string[];
}

export interface EMICalculationRequest {
  principal: number;
  interestRate: number;
  tenure: number;
}

export interface EligibilityRequest {
  userId: number;
  loanTypeId: number;
  amount: number;
  monthlyIncome: number;
  existingEmis: number;
}

@Injectable({
  providedIn: 'root'
})
export class LoanService {
  private apiUrl = 'http://localhost:9090/api/loans';
  private loanTypeApiUrl = 'http://localhost:9090/api/loan-types';

  constructor(private http: HttpClient) {}

  // Loan Type APIs
  getAllActiveLoanTypes(): Observable<LoanType[]> {
    return this.http.get<LoanType[]>(this.loanTypeApiUrl);
  }

  getLoanTypeById(id: number): Observable<LoanType> {
    return this.http.get<LoanType>(`${this.loanTypeApiUrl}/${id}`);
  }

  // Customer Loan APIs
  getUserLoans(userId: number): Observable<Loan[]> {
    return this.http.get<Loan[]>(`${this.apiUrl}/user/${userId}`);
  }

  applyForLoan(request: LoanApplicationRequest): Observable<Loan> {
    return this.http.post<Loan>(`${this.apiUrl}/apply`, request);
  }

  calculateEMI(request: EMICalculationRequest): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/calculate-emi`, request);
  }

  checkEligibility(request: EligibilityRequest): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/check-eligibility`, request);
  }

  getLoanById(loanId: number): Observable<Loan> {
    return this.http.get<Loan>(`${this.apiUrl}/${loanId}`);
  }

  // Employee Loan APIs
  getAllLoans(): Observable<Loan[]> {
    return this.http.get<Loan[]>(this.apiUrl);
  }

  getPendingLoans(): Observable<Loan[]> {
    return this.http.get<Loan[]>(`${this.apiUrl}/pending`);
  }

  approveLoan(loanId: number, comments: string, employeeId: number): Observable<Loan> {
    return this.http.post<Loan>(`${this.apiUrl}/${loanId}/approve`, {
      employeeId: employeeId,
      comments: comments
    });
  }

  rejectLoan(loanId: number, comments: string, employeeId: number): Observable<Loan> {
    return this.http.post<Loan>(`${this.apiUrl}/${loanId}/reject`, {
      employeeId: employeeId,
      comments: comments
    });
  }

  disburseLoan(loanId: number, employeeId: number): Observable<Loan> {
    return this.http.post<Loan>(`${this.apiUrl}/${loanId}/disburse`, {
      employeeId: employeeId
    });
  }

  // Admin Loan Type APIs (for future use)
  createLoanType(loanType: LoanType): Observable<LoanType> {
    return this.http.post<LoanType>(this.loanTypeApiUrl, loanType);
  }

  updateLoanType(id: number, loanType: LoanType): Observable<LoanType> {
    return this.http.put<LoanType>(`${this.loanTypeApiUrl}/${id}`, loanType);
  }

  deleteLoanType(id: number): Observable<any> {
    return this.http.delete(`${this.loanTypeApiUrl}/${id}`);
  }

  getAllLoanTypes(): Observable<LoanType[]> {
    return this.http.get<LoanType[]>(`${this.loanTypeApiUrl}/all`);
  }
}
