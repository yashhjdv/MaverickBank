import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { 
  AccountManagementService, 
  CreateAccountRequest
} from '../../services/account-management.service';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-customer-account-request',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './customer-account-request.component.html',
  styleUrls: ['./customer-account-request.component.css']
})
export class CustomerAccountRequestComponent implements OnInit {
  // UI state
  isSubmitting = false;
  
  // Forms
  accountRequestForm: FormGroup;
  
  // Current user 
  currentUser: User | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private accountService: AccountManagementService,
    private authService: AuthService
  ) {
    this.accountRequestForm = this.createAccountRequestForm();
  }

  ngOnInit(): void {
    // Get current user from auth service
    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        // Auto-fill user ID
        this.accountRequestForm.patchValue({
          userId: user.id
        });
      } else {
        this.router.navigate(['/']);
      }
    });
  }

  private createAccountRequestForm(): FormGroup {
    return this.fb.group({
      // User Information (auto-filled from logged-in user)
      userId: ['', [Validators.required]],
      
      // Account Information - only 5 fields as per backend API
      accountType: ['', Validators.required],
      ifscCode: ['', [Validators.required]],
      branchName: ['', [Validators.required]],
      branchAddress: ['', [Validators.required]]
    });
  }

  // Submit account request - REAL API
  submitAccountRequest(): void {
    if (this.accountRequestForm.valid && !this.isSubmitting) {
      this.isSubmitting = true;
      
      const requestData: CreateAccountRequest = {
        ...this.accountRequestForm.value
      };
      
      this.accountService.submitAccountRequest(requestData).subscribe({
        next: (response: any) => {
          console.log('Account request submitted successfully:', response);
          this.isSubmitting = false;
          alert('Account request submitted successfully! You will be notified once it is processed.');
          this.router.navigate(['/dashboard']);
        },
        error: (error: any) => {
          console.error('Error submitting account request:', error);
          this.isSubmitting = false;
          alert('Error submitting account request. Please try again.');
        }
      });
    } else {
      this.markFormGroupTouched();
      alert('Please fill all required fields correctly.');
    }
  }

  // Mark all form fields as touched to show validation errors
  private markFormGroupTouched(): void {
    Object.keys(this.accountRequestForm.controls).forEach(key => {
      const control = this.accountRequestForm.get(key);
      control?.markAsTouched();
    });
  }

  // Check if form field has error and is touched
  isFieldInvalid(fieldName: string): boolean {
    const field = this.accountRequestForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  // Get error message for a field
  getFieldError(fieldName: string): string {
    const field = this.accountRequestForm.get(fieldName);
    if (field && field.errors && field.touched) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['minlength']) return `${fieldName} is too short`;
      if (field.errors['pattern']) return `${fieldName} format is invalid`;
    }
    return '';
  }

  // Navigate back to dashboard
  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
