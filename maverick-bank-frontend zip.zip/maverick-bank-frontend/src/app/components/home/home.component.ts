import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';
import { LOGO_PATHS } from '../../shared/logo';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loginForm: FormGroup;
  isLoading = false;
  showMobileMenu = false;

  // Navigation items
  navItems = [
    { label: 'Home', action: 'scrollToTop' },
    { label: 'Services', action: 'scrollToFeatures' },
    { label: 'Loans', action: 'showLoginPrompt' },
    { label: 'Accounts', action: 'showLoginPrompt' },
    { label: 'Support', action: 'showLoginPrompt' },
    { label: 'Contact', action: 'scrollToContact' }
  ];

  // Features data
  features = [
    {
      icon: '🏦',
      title: 'Open Account Instantly',
      description: 'Start your banking journey in minutes with our digital account opening process.',
      gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
    },
    {
      icon: '💰',
      title: 'Online Loan Application',
      description: 'Apply for personal, home, or business loans with competitive interest rates.',
      gradient: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
    },
    {
      icon: '⚡',
      title: 'Real-time Transactions',
      description: 'Transfer money instantly with our secure and fast payment system.',
      gradient: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)'
    }
  ];

  // Security features
  securityFeatures = [
    {
      icon: '🔐',
      title: '2FA Authentication',
      description: 'Two-factor authentication for enhanced security'
    },
    {
      icon: '🛡️',
      title: 'End-to-End Encryption',
      description: 'Bank-grade encryption for all transactions'
    },
    {
      icon: '✅',
      title: 'RBI Compliance',
      description: 'Fully compliant with RBI regulations'
    }
  ];

  // Testimonials
  testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Business Owner',
      content: 'Maverick Bank has transformed how I manage my business finances. The digital platform is incredibly user-friendly.',
      rating: 5,
      avatar: '👩‍💼'
    },
    {
      name: 'Rajesh Kumar',
      role: 'Software Engineer',
      content: 'The instant loan approval and seamless transactions make Maverick my go-to bank for all financial needs.',
      rating: 5,
      avatar: '👨‍💻'
    },
    {
      name: 'Anita Patel',
      role: 'Freelancer',
      content: 'Opening an account was so quick and easy. The mobile app is fantastic for managing finances on the go.',
      rating: 5,
      avatar: '👩‍🎨'
    }
  ];

  private logoIndex = 0;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService
  ) {
    this.loginForm = this.createLoginForm();
  }

  ngOnInit(): void {
    // Check if user is already logged in
    if (this.authService.getToken()) {
      this.router.navigate(['/dashboard']);
    }
  }

  createLoginForm(): FormGroup {
    return this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      this.isLoading = true;
      const credentials = {
        username: this.loginForm.value.username,
        password: this.loginForm.value.password
      };

      this.authService.login(credentials).subscribe({
        next: (response) => {
          this.notificationService.success('Login successful!');
          this.router.navigate(['/dashboard']);
        },
        error: (error) => {
          console.error('Login error:', error);
          this.notificationService.error('Invalid credentials. Please try again.');
          this.isLoading = false;
        }
      });
    } else {
      this.notificationService.error('Please fill all required fields correctly.');
    }
  }

  navigateToRegister(): void {
    this.router.navigate(['/register']);
  }

  // Navigation methods
  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  scrollToFeatures(): void {
    const element = document.getElementById('features');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  scrollToContact(): void {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  showLoginPrompt(): void {
    this.notificationService.info('Please login first to access this feature');
    const loginSection = document.getElementById('login-section');
    if (loginSection) {
      loginSection.scrollIntoView({ behavior: 'smooth' });
    }
  }

  handleNavAction(action: string): void {
    switch (action) {
      case 'scrollToTop':
        this.scrollToTop();
        break;
      case 'scrollToFeatures':
        this.scrollToFeatures();
        break;
      case 'scrollToContact':
        this.scrollToContact();
        break;
      case 'showLoginPrompt':
        this.showLoginPrompt();
        break;
    }
    this.showMobileMenu = false;
  }

  toggleMobileMenu(): void {
    this.showMobileMenu = !this.showMobileMenu;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.loginForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.loginForm.get(fieldName);
    if (field && field.errors && field.touched) {
      const errors = field.errors;
      if (errors['required']) return `${fieldName} is required`;
      if (errors['minlength']) return `Password must be at least ${errors['minlength'].requiredLength} characters`;
    }
    return '';
  }

  generateStars(rating: number): string[] {
    return Array(5).fill(0).map((_, i) => i < rating ? '★' : '☆');
  }

  onLogoError(event: any) {
    this.logoIndex++;
    if (this.logoIndex < LOGO_PATHS.length) {
      event.target.src = LOGO_PATHS[this.logoIndex];
    }
  }
}
