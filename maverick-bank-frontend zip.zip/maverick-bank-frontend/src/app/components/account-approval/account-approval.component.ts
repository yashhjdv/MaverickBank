import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AccountRequestService, AccountRequest } from '../../services/account-request.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-account-approval',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './account-approval.component.html',
  styleUrls: ['./account-approval.component.css']
})
export class AccountApprovalComponent implements OnInit {
  pendingRequests: AccountRequest[] = [];
  selectedRequest: AccountRequest | null = null;
  isLoading = false;
  showDetails = false;
  
  // Form data
  approvalComments = '';
  rejectionComments = '';
  showApprovalForm = false;
  showRejectionForm = false;

  constructor(
    private accountRequestService: AccountRequestService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadPendingRequests();
  }

  loadPendingRequests(): void {
    this.isLoading = true;
    this.accountRequestService.getAllPendingRequests().subscribe({
      next: (requests) => {
        this.pendingRequests = requests;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading requests:', error);
        this.notificationService.error('Failed to load pending requests');
        this.isLoading = false;
      }
    });
  }

  viewDetails(request: AccountRequest): void {
    this.selectedRequest = request;
    this.showDetails = true;
  }

  closeDetails(): void {
    this.showDetails = false;
    this.selectedRequest = null;
    this.resetForms();
  }

  startApproval(request: AccountRequest): void {
    this.selectedRequest = request;
    this.showApprovalForm = true;
    this.showRejectionForm = false;
  }

  startRejection(request: AccountRequest): void {
    this.selectedRequest = request;
    this.showRejectionForm = true;
    this.showApprovalForm = false;
  }

  approveRequest(): void {
    if (!this.selectedRequest) return;

    this.accountRequestService.approveRequest(this.selectedRequest.id, this.approvalComments).subscribe({
      next: (response) => {
        this.notificationService.success(`Account request for ${this.selectedRequest!.customerName} approved successfully!`);
        this.loadPendingRequests();
        this.resetForms();
      },
      error: (error) => {
        console.error('Error approving request:', error);
        this.notificationService.error('Failed to approve request');
      }
    });
  }

  rejectRequest(): void {
    if (!this.selectedRequest || !this.rejectionComments.trim()) {
      this.notificationService.error('Please provide rejection comments');
      return;
    }

    this.accountRequestService.rejectRequest(this.selectedRequest.id, this.rejectionComments).subscribe({
      next: (response) => {
        this.notificationService.success(`Account request for ${this.selectedRequest!.customerName} rejected`);
        this.loadPendingRequests();
        this.resetForms();
      },
      error: (error) => {
        console.error('Error rejecting request:', error);
        this.notificationService.error('Failed to reject request');
      }
    });
  }

  resetForms(): void {
    this.showApprovalForm = false;
    this.showRejectionForm = false;
    this.approvalComments = '';
    this.rejectionComments = '';
    this.selectedRequest = null;
  }

  getDocumentVerificationStatus(request: AccountRequest): string {
    const total = request.documents.length;
    const verified = request.documents.filter(doc => doc.verified).length;
    return `${verified}/${total}`;
  }

  isAllDocumentsVerified(request: AccountRequest): boolean {
    return request.documents.every(doc => doc.verified);
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getStatusColor(status: string): string {
    switch (status) {
      case 'PENDING': return '#ffc107';
      case 'APPROVED': return '#28a745';
      case 'REJECTED': return '#dc3545';
      default: return '#6c757d';
    }
  }
}
