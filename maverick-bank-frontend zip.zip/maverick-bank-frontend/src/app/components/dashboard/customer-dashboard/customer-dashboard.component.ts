import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService, User } from '../../../services/auth.service';
import { AccountManagementService, Account, Transaction } from '../../../services/account-management.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './customer-dashboard.component.html',
  styleUrls: ['./customer-dashboard.component.css']
})
export class CustomerDashboardComponent implements OnInit {
  user: User | null = null;
  userAccounts: Account[] = [];
  recentTransactions: Transaction[] = [];
  isLoadingAccounts = false;
  isLoadingTransactions = false;

  // Dashboard stats
  totalBalance = 0;
  monthlySpending = 0;
  savingsGrowth = 0;
  activeAccounts = 0;

  constructor(
    private authService: AuthService,
    private accountService: AccountManagementService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      if (user) {
        this.loadUserData();
      }
    });
  }

  loadUserData(): void {
    this.loadUserAccounts();
    this.loadRecentTransactions();
  }

  loadUserAccounts(): void {
    if (!this.user?.id) return;
    
    this.isLoadingAccounts = true;
    this.accountService.getUserAccounts(this.user.id).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts;
        this.calculateDashboardStats();
        this.isLoadingAccounts = false;
      },
      error: (error) => {
        console.error('Error loading user accounts:', error);
        this.isLoadingAccounts = false;
        this.notificationService.error('Failed to load your accounts');
      }
    });
  }

  loadRecentTransactions(): void {
    if (!this.user?.id) return;

    this.isLoadingTransactions = true;
    this.accountService.getUserRecentTransactions(this.user.id, 5).subscribe({
      next: (transactions) => {
        this.recentTransactions = transactions;
        this.isLoadingTransactions = false;
      },
      error: (error) => {
        console.error('Error loading recent transactions:', error);
        this.isLoadingTransactions = false;
        // Use mock data for demo
        this.recentTransactions = this.getMockTransactions();
      }
    });
  }

  calculateDashboardStats(): void {
    this.totalBalance = this.userAccounts.reduce((sum, account) => sum + account.balance, 0);
    this.activeAccounts = this.userAccounts.filter(account => account.isActive).length;
    
    // Mock calculations for demo
    this.monthlySpending = 15420;
    this.savingsGrowth = 2.5;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getAccountTypeIcon(type: string): string {
    switch (type.toUpperCase()) {
      case 'SAVINGS':
        return '🏦';
      case 'CURRENT':
        return '💼';
      case 'FIXED_DEPOSIT':
        return '🏅';
      default:
        return '💳';
    }
  }

  getTransactionIcon(type: string): string {
    return type === 'CREDIT' ? '⬆️' : '⬇️';
  }

  getTransactionClass(type: string): string {
    return type === 'CREDIT' ? 'credit' : 'debit';
  }



  // Quick actions
  onQuickTransfer(): void {
    this.notificationService.info('Redirecting to transfer page...');
    // Router navigation will be handled by routerLink in template
  }

  onQuickDeposit(): void {
    this.notificationService.info('Redirecting to deposit page...');
  }

  onViewStatements(): void {
    this.notificationService.info('Statements feature coming soon!');
  }

  onPayBills(): void {
    this.notificationService.info('Bill payment feature coming soon!');
  }

  // Mock data for development
  private getMockTransactions(): Transaction[] {
    return [
      {
        id: 1,
        accountId: 1,
        transactionType: 'CREDIT',
        amount: 5000,
        description: 'Salary Credit',
        timestamp: new Date('2024-01-15T10:30:00'),
        balance: 30000
      },
      {
        id: 2,
        accountId: 1,
        transactionType: 'DEBIT',
        amount: 1200,
        description: 'ATM Withdrawal',
        timestamp: new Date('2024-01-14T14:20:00'),
        balance: 25000
      },
      {
        id: 3,
        accountId: 1,
        transactionType: 'DEBIT',
        amount: 850,
        description: 'Online Shopping',
        timestamp: new Date('2024-01-13T16:45:00'),
        balance: 26200
      }
    ];
  }

  getCurrentDate(): string {
    return new Date().toLocaleString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  scrollToReports(): void {
    const element = document.getElementById('reports-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
