import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService, User } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';
import { EmployeeReportsComponent } from '../../employee-reports/employee-reports.component';

@Component({
  selector: 'app-employee-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, EmployeeReportsComponent],
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {
  user: User | null = null;

  // Employee statistics
  pendingRequests = 8;
  loanApplications = 5;
  customersServed = 24;
  dailyTarget = 80;

  constructor(
    private authService: AuthService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      this.loadEmployeeDashboard();
    });
  }

  loadEmployeeDashboard(): void {
    // Load employee-specific data
    this.notificationService.info('Loading employee dashboard...');
  }

  onReviewAccountRequests(): void {
    this.router.navigate(['/employee-accounts']);
  }

  onApproveLoan(): void {
    this.notificationService.info('Loan approval feature will be available soon!');
  }

  onCustomerSupport(): void {
    this.notificationService.info('Customer support feature will be available soon!');
  }

  onGenerateReports(): void {
    this.notificationService.info('Reports feature will be available soon!');
  }

  onSearchCustomer(): void {
    this.notificationService.info('Customer search feature will be available soon!');
  }

  onOpenAccount(): void {
    this.router.navigate(['/employee-accounts']);
  }

  scrollToReports(): void {
    const element = document.getElementById('reports-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
