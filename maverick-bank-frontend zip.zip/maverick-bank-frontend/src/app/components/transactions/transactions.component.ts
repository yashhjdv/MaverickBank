import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService, User } from '../../services/auth.service';
import { AccountManagementService, Account, Transaction } from '../../services/account-management.service';
import { BeneficiaryService, Beneficiary } from '../../services/beneficiary.service';
import { NotificationService } from '../../services/notification.service';
import { NotificationComponent } from '../notifications/notification.component';

@Component({
  selector: 'app-transactions',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule],
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  user: User | null = null;
  userAccounts: Account[] = [];
  selectedAccount: Account | null = null;
  transactions: Transaction[] = [];
  recentTransactions: Transaction[] = [];
  userBeneficiaries: Beneficiary[] = [];
  
  // Form states
  depositForm: FormGroup;
  withdrawForm: FormGroup;
  transferForm: FormGroup;
  beneficiaryTransferForm: FormGroup;
  
  // UI states
  isLoadingAccounts = false;
  isLoadingTransactions = false;
  isSubmittingTransaction = false;
  selectedTab = 'history'; // 'history', 'deposit', 'withdraw', 'transfer', 'beneficiary-transfer'
  
  // Filter options
  transactionFilter = 'recent'; // 'recent', 'month', 'all'

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private accountService: AccountManagementService,
    private beneficiaryService: BeneficiaryService,
    private notificationService: NotificationService
  ) {
    this.depositForm = this.fb.group({
      accountId: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]],
      description: ['']
    });

    this.withdrawForm = this.fb.group({
      accountId: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]],
      description: ['']
    });

    this.transferForm = this.fb.group({
      fromAccountId: ['', Validators.required],
      toAccountNumber: ['', [Validators.required, Validators.pattern(/^\d{9,18}$/)]],
      amount: ['', [Validators.required, Validators.min(1)]],
      description: ['']
    });

    this.beneficiaryTransferForm = this.fb.group({
      fromAccountId: ['', Validators.required],
      beneficiaryId: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]],
      description: ['']
    });
  }

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      if (user) {
        this.loadUserAccounts();
        this.loadUserBeneficiaries();
      }
    });
  }

  loadUserAccounts(): void {
    if (!this.user?.id) return;
    
    this.isLoadingAccounts = true;
    this.accountService.getUserAccounts(this.user.id).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts;
        this.isLoadingAccounts = false;
        
        if (accounts.length > 0) {
          this.selectedAccount = accounts[0];
          this.loadTransactions();
          this.loadRecentTransactions();
        }
      },
      error: (error) => {
        console.error('Error loading accounts:', error);
        this.isLoadingAccounts = false;
        this.notificationService.error('Failed to load your accounts');
      }
    });
  }

  onAccountChange(account: Account): void {
    this.selectedAccount = account;
    this.loadTransactions();
    this.loadRecentTransactions();
  }

  onAccountSelection(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const index = +target.value;
    if (this.userAccounts[index]) {
      this.onAccountChange(this.userAccounts[index]);
    }
  }

  loadTransactions(): void {
    if (!this.selectedAccount) return;

    this.isLoadingTransactions = true;
    const filter = this.getTransactionFilter();
    
    this.accountService.getAccountTransactions(this.selectedAccount.id, filter).subscribe({
      next: (transactions) => {
        this.transactions = transactions;
        this.isLoadingTransactions = false;
      },
      error: (error) => {
        console.error('Error loading transactions:', error);
        this.isLoadingTransactions = false;
        this.notificationService.error('Failed to load transactions');
      }
    });
  }

  loadRecentTransactions(): void {
    if (!this.selectedAccount) return;

    this.accountService.getLastNTransactions(this.selectedAccount.id, 5).subscribe({
      next: (transactions) => {
        this.recentTransactions = transactions;
      },
      error: (error) => {
        console.error('Error loading recent transactions:', error);
      }
    });
  }

  loadUserBeneficiaries(): void {
    if (!this.user?.id) return;
    
    this.beneficiaryService.getUserBeneficiaries(this.user.id).subscribe({
      next: (beneficiaries) => {
        this.userBeneficiaries = beneficiaries;
      },
      error: (error) => {
        console.error('Error loading beneficiaries:', error);
        this.notificationService.error('Failed to load beneficiaries');
      }
    });
  }

  getTransactionFilter() {
    switch (this.transactionFilter) {
      case 'recent':
        return { type: 'last10' as const };
      case 'month':
        return { type: 'lastMonth' as const };
      default:
        return { type: 'all' as const };
    }
  }

  onFilterChange(): void {
    this.loadTransactions();
  }

  // Transaction operations
  onDeposit(): void {
    if (this.depositForm.valid) {
      this.isSubmittingTransaction = true;
      const { accountId, amount, description } = this.depositForm.value;
      
      this.accountService.deposit(accountId, amount, description).subscribe({
        next: (transaction) => {
          this.isSubmittingTransaction = false;
          this.notificationService.success('Deposit successful!');
          this.depositForm.reset();
          this.loadTransactions();
          this.loadUserAccounts(); // Refresh account balances
        },
        error: (error) => {
          this.isSubmittingTransaction = false;
          this.notificationService.error('Deposit failed. Please try again.');
          console.error('Deposit error:', error);
        }
      });
    }
  }

  onWithdraw(): void {
    if (this.withdrawForm.valid) {
      this.isSubmittingTransaction = true;
      const { accountId, amount, description } = this.withdrawForm.value;
      
      this.accountService.withdraw(accountId, amount, description).subscribe({
        next: (transaction) => {
          this.isSubmittingTransaction = false;
          this.notificationService.success('Withdrawal successful!');
          this.withdrawForm.reset();
          this.loadTransactions();
          this.loadUserAccounts(); // Refresh account balances
        },
        error: (error) => {
          this.isSubmittingTransaction = false;
          this.notificationService.error('Withdrawal failed. Please check your balance.');
          console.error('Withdrawal error:', error);
        }
      });
    }
  }

  onTransfer(): void {
    if (this.transferForm.valid) {
      this.isSubmittingTransaction = true;
      const { fromAccountId, toAccountNumber, amount, description } = this.transferForm.value;
      
      this.accountService.transferByAccountNumber(fromAccountId, toAccountNumber, amount, description).subscribe({
        next: (transaction) => {
          this.isSubmittingTransaction = false;
          this.notificationService.success('Transfer successful!');
          this.transferForm.reset();
          this.loadTransactions();
          this.loadUserAccounts(); // Refresh account balances
        },
        error: (error) => {
          this.isSubmittingTransaction = false;
          this.notificationService.error('Transfer failed. Please check account details.');
          console.error('Transfer error:', error);
        }
      });
    }
  }

  onBeneficiaryTransfer(): void {
    if (this.beneficiaryTransferForm.invalid) return;

    this.isSubmittingTransaction = true;
    const formValue = this.beneficiaryTransferForm.value;

    this.accountService.transferToBeneficiary(
      formValue.fromAccountId,
      formValue.beneficiaryId,
      formValue.amount,
      formValue.description
    ).subscribe({
      next: (transaction) => {
        this.isSubmittingTransaction = false;
        this.notificationService.success('Transfer to beneficiary completed successfully');
        this.beneficiaryTransferForm.reset();
        this.loadUserAccounts(); // Refresh balances
        this.loadTransactions(); // Refresh transaction history
      },
      error: (error) => {
        this.isSubmittingTransaction = false;
        this.notificationService.error('Transfer failed: ' + error.message);
      }
    });
  }

  getTabDisplayName(tab: string): string {
    switch (tab) {
      case 'history': return 'History';
      case 'deposit': return 'Deposit';
      case 'withdraw': return 'Withdraw';
      case 'transfer': return 'Transfer (Bank)';
      case 'beneficiary-transfer': return 'To Beneficiary';
      default: return tab;
    }
  }

  // Utility methods
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getTransactionTypeClass(type: string): string {
    return type === 'CREDIT' ? 'text-green-600' : 'text-red-600';
  }

  getTransactionIcon(type: string): string {
    return type === 'CREDIT' ? '↑' : '↓';
  }

  // Form validation helpers
  isFieldInvalid(formGroup: FormGroup, fieldName: string): boolean {
    const field = formGroup.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(formGroup: FormGroup, fieldName: string): string {
    const field = formGroup.get(fieldName);
    if (field && field.errors && field.touched) {
      if (field.errors['required']) {
        return `${fieldName} is required`;
      }
      if (field.errors['min']) {
        return `${fieldName} must be greater than ${field.errors['min'].min}`;
      }
    }
    return '';
  }
}
