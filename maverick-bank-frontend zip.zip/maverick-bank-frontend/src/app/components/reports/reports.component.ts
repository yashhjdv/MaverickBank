import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportService, Account, Transaction, Loan, ReportSummary } from '../../services/report.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="reports-container">
      <!-- Report Summary Cards -->
      <div class="summary-cards" *ngIf="reportSummary">
        <div class="summary-card total-balance">
          <div class="card-icon">💰</div>
          <div class="card-content">
            <h3>Total Balance</h3>
            <p class="amount">₹{{ reportSummary.totalBalance | number:'1.2-2' }}</p>
          </div>
        </div>
        
        <div class="summary-card accounts">
          <div class="card-icon">🏦</div>
          <div class="card-content">
            <h3>Total Accounts</h3>
            <p class="count">{{ reportSummary.totalAccounts }}</p>
            <small>{{ reportSummary.activeAccounts }} Active</small>
          </div>
        </div>
        
        <div class="summary-card transactions">
          <div class="card-icon">💸</div>
          <div class="card-content">
            <h3>Total Transactions</h3>
            <p class="count">{{ reportSummary.totalTransactions }}</p>
          </div>
        </div>
        
        <div class="summary-card loans">
          <div class="card-icon">📋</div>
          <div class="card-content">
            <h3>Total Loans</h3>
            <p class="count">{{ reportSummary.totalLoans }}</p>
            <small>{{ reportSummary.pendingLoans }} Pending, {{ reportSummary.approvedLoans }} Approved</small>
          </div>
        </div>
      </div>

      <!-- Report Actions -->
      <div class="report-actions">
        <div class="action-group">
          <h3>📊 Generate Reports</h3>
          <div class="action-buttons">
            <button class="btn btn-primary" (click)="loadAccountsReport()" [disabled]="isLoading">
              <span class="btn-icon">🏦</span>
              {{ isLoading && activeReport === 'accounts' ? 'Loading...' : 'Accounts Report' }}
            </button>
            
            <button class="btn btn-secondary" (click)="loadTransactionsReport()" [disabled]="isLoading">
              <span class="btn-icon">💸</span>
              {{ isLoading && activeReport === 'transactions' ? 'Loading...' : 'Transactions Report' }}
            </button>
            
            <button class="btn btn-success" (click)="loadLoansReport()" [disabled]="isLoading">
              <span class="btn-icon">📋</span>
              {{ isLoading && activeReport === 'loans' ? 'Loading...' : 'Loans Report' }}
            </button>
          </div>
        </div>

        <div class="action-group">
          <h3>📥 Export Data</h3>
          <div class="action-buttons">
            <button class="btn btn-outline" (click)="exportAccounts()" [disabled]="isExporting">
              <span class="btn-icon">📄</span>
              Export Accounts CSV
            </button>
            
            <button class="btn btn-outline" (click)="exportTransactions()" [disabled]="isExporting">
              <span class="btn-icon">📄</span>
              Export Transactions CSV
            </button>
            
            <button class="btn btn-outline" (click)="exportLoans()" [disabled]="isExporting">
              <span class="btn-icon">📄</span>
              Export Loans CSV
            </button>
          </div>
        </div>
      </div>

      <!-- Report Data Display -->
      <div class="report-data" *ngIf="currentReportData.length > 0">
        <div class="report-header">
          <h3>{{ getReportTitle() }}</h3>
          <span class="record-count">{{ currentReportData.length }} records found</span>
        </div>

        <!-- Accounts Report Table -->
        <div class="report-table" *ngIf="activeReport === 'accounts'">
          <table class="data-table">
            <thead>
              <tr>
                <th>Account ID</th>
                <th>Account Number</th>
                <th>Type</th>
                <th>Balance</th>
                <th>Status</th>
                <th>User ID</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let account of currentReportData" class="data-row">
                <td>{{ account.id }}</td>
                <td>{{ account.accountNumber }}</td>
                <td>
                  <span class="account-type" [class]="'type-' + account.accountType.toLowerCase()">
                    {{ account.accountType }}
                  </span>
                </td>
                <td class="amount">₹{{ account.balance | number:'1.2-2' }}</td>
                <td>
                  <span class="status" [class]="'status-' + account.status.toLowerCase()">
                    {{ account.status }}
                  </span>
                </td>
                <td>{{ account.userId }}</td>
                <td>{{ formatDate(account.createdAt) }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Transactions Report Table -->
        <div class="report-table" *ngIf="activeReport === 'transactions'">
          <table class="data-table">
            <thead>
              <tr>
                <th>Transaction ID</th>
                <th>Account ID</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Date</th>
                <th>From/To Account</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let transaction of currentReportData" class="data-row">
                <td>{{ transaction.id }}</td>
                <td>{{ transaction.accountId }}</td>
                <td>
                  <span class="transaction-type" [class]="'type-' + transaction.transactionType.toLowerCase()">
                    {{ transaction.transactionType }}
                  </span>
                </td>
                <td class="amount" [class]="getAmountClass(transaction.transactionType)">
                  ₹{{ transaction.amount | number:'1.2-2' }}
                </td>
                <td class="description">{{ transaction.description }}</td>
                <td>{{ formatDate(transaction.timestamp) }}</td>
                <td>
                  <span *ngIf="transaction.fromAccountId">From: {{ transaction.fromAccountId }}</span>
                  <span *ngIf="transaction.toAccountId">To: {{ transaction.toAccountId }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Loans Report Table -->
        <div class="report-table" *ngIf="activeReport === 'loans'">
          <table class="data-table">
            <thead>
              <tr>
                <th>Loan ID</th>
                <th>User ID</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Interest Rate</th>
                <th>Tenure</th>
                <th>Status</th>
                <th>Applied Date</th>
                <th>Approved Date</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let loan of currentReportData" class="data-row">
                <td>{{ loan.id }}</td>
                <td>{{ loan.userId }}</td>
                <td>
                  <span class="loan-type">{{ loan.loanType }}</span>
                </td>
                <td class="amount">₹{{ loan.loanAmount | number:'1.2-2' }}</td>
                <td>{{ loan.interestRate }}%</td>
                <td>{{ loan.tenure }} months</td>
                <td>
                  <span class="status" [class]="'status-' + loan.status.toLowerCase()">
                    {{ loan.status }}
                  </span>
                </td>
                <td>{{ formatDate(loan.appliedDate) }}</td>
                <td>{{ loan.approvedDate ? formatDate(loan.approvedDate) : '-' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Loading State -->
      <div class="loading-state" *ngIf="isLoading">
        <div class="loading-spinner"></div>
        <p>Loading {{ activeReport }} report...</p>
      </div>

      <!-- No Data State -->
      <div class="no-data-state" *ngIf="!isLoading && currentReportData.length === 0 && activeReport">
        <div class="no-data-icon">📊</div>
        <h3>No Data Found</h3>
        <p>No {{ activeReport }} data available at the moment.</p>
      </div>
    </div>
  `,
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  @Input() userRole: string = 'ADMIN'; // Role-based access control

  reportSummary: ReportSummary | null = null;
  currentReportData: any[] = [];
  activeReport: string = '';
  isLoading = false;
  isExporting = false;

  constructor(
    private reportService: ReportService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadReportSummary();
  }

  loadReportSummary(): void {
    this.reportService.getReportSummary().subscribe({
      next: (summary) => {
        this.reportSummary = summary;
      },
      error: (error) => {
        console.error('Error loading report summary:', error);
        this.notificationService.error('Failed to load report summary');
      }
    });
  }

  loadAccountsReport(): void {
    if (!this.hasPermission('accounts')) {
      this.notificationService.error('You do not have permission to view accounts report');
      return;
    }

    this.isLoading = true;
    this.activeReport = 'accounts';
    
    this.reportService.getAllAccounts().subscribe({
      next: (accounts) => {
        this.currentReportData = accounts;
        this.isLoading = false;
        this.notificationService.success(`Loaded ${accounts.length} accounts`);
      },
      error: (error) => {
        console.error('Error loading accounts report:', error);
        this.isLoading = false;
        this.notificationService.error('Failed to load accounts report');
      }
    });
  }

  loadTransactionsReport(): void {
    if (!this.hasPermission('transactions')) {
      this.notificationService.error('You do not have permission to view transactions report');
      return;
    }

    this.isLoading = true;
    this.activeReport = 'transactions';
    
    this.reportService.getAllTransactions().subscribe({
      next: (transactions) => {
        this.currentReportData = transactions;
        this.isLoading = false;
        this.notificationService.success(`Loaded ${transactions.length} transactions`);
      },
      error: (error) => {
        console.error('Error loading transactions report:', error);
        this.isLoading = false;
        this.notificationService.error('Failed to load transactions report');
      }
    });
  }

  loadLoansReport(): void {
    if (!this.hasPermission('loans')) {
      this.notificationService.error('You do not have permission to view loans report');
      return;
    }

    this.isLoading = true;
    this.activeReport = 'loans';
    
    this.reportService.getAllLoans().subscribe({
      next: (loans) => {
        this.currentReportData = loans;
        this.isLoading = false;
        this.notificationService.success(`Loaded ${loans.length} loans`);
      },
      error: (error) => {
        console.error('Error loading loans report:', error);
        this.isLoading = false;
        this.notificationService.error('Failed to load loans report');
      }
    });
  }

  exportAccounts(): void {
    if (!this.hasPermission('accounts')) {
      this.notificationService.error('You do not have permission to export accounts data');
      return;
    }

    this.isExporting = true;
    this.reportService.exportAccountsToCSV();
    this.isExporting = false;
    this.notificationService.success('Accounts data exported successfully');
  }

  exportTransactions(): void {
    if (!this.hasPermission('transactions')) {
      this.notificationService.error('You do not have permission to export transactions data');
      return;
    }

    this.isExporting = true;
    this.reportService.exportTransactionsToCSV();
    this.isExporting = false;
    this.notificationService.success('Transactions data exported successfully');
  }

  exportLoans(): void {
    if (!this.hasPermission('loans')) {
      this.notificationService.error('You do not have permission to export loans data');
      return;
    }

    this.isExporting = true;
    this.reportService.exportLoansToCSV();
    this.isExporting = false;
    this.notificationService.success('Loans data exported successfully');
  }

  hasPermission(reportType: string): boolean {
    // Role-based access control
    switch (this.userRole) {
      case 'ADMIN':
        return true; // Admin can access all reports
      case 'MANAGER':
        return ['accounts', 'transactions', 'loans'].includes(reportType);
      case 'EMPLOYEE':
        return ['accounts', 'transactions'].includes(reportType);
      case 'CUSTOMER':
        return false; // Customers cannot access reports
      default:
        return false;
    }
  }

  getReportTitle(): string {
    switch (this.activeReport) {
      case 'accounts':
        return '🏦 Accounts Report';
      case 'transactions':
        return '💸 Transactions Report';
      case 'loans':
        return '📋 Loans Report';
      default:
        return '📊 Report';
    }
  }

  formatDate(dateString: string): string {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  getAmountClass(transactionType: string): string {
    switch (transactionType?.toLowerCase()) {
      case 'credit':
      case 'deposit':
        return 'amount-positive';
      case 'debit':
      case 'withdrawal':
        return 'amount-negative';
      default:
        return '';
    }
  }
}
