import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService, Notification } from '../../services/notification.service';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="notifications-container">
      <div 
        *ngFor="let notification of notifications" 
        class="notification"
        [ngClass]="'notification-' + notification.type"
        (click)="removeNotification(notification.id)"
      >
        <div class="notification-content">
          <span class="notification-icon">
            <ng-container [ngSwitch]="notification.type">
              <span *ngSwitchCase="'success'">✓</span>
              <span *ngSwitchCase="'error'">✗</span>
              <span *ngSwitchCase="'warning'">⚠</span>
              <span *ngSwitchDefault>ℹ</span>
            </ng-container>
          </span>
          <span class="notification-message">{{ notification.message }}</span>
        </div>
        <button class="notification-close" (click)="removeNotification(notification.id)">×</button>
      </div>
    </div>
  `,
  styles: [`
    .notifications-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1000;
      max-width: 400px;
    }

    .notification {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      margin-bottom: 10px;
      padding: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      transition: transform 0.2s ease;
      border-left: 4px solid transparent;
    }

    .notification:hover {
      transform: translateX(-5px);
    }

    .notification-success {
      border-left-color: #10B981;
    }

    .notification-error {
      border-left-color: #EF4444;
    }

    .notification-warning {
      border-left-color: #F59E0B;
    }

    .notification-info {
      border-left-color: #3B82F6;
    }

    .notification-content {
      display: flex;
      align-items: center;
      flex: 1;
    }

    .notification-icon {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 12px;
      font-weight: bold;
      color: white;
      font-size: 12px;
    }

    .notification-success .notification-icon {
      background-color: #10B981;
    }

    .notification-error .notification-icon {
      background-color: #EF4444;
    }

    .notification-warning .notification-icon {
      background-color: #F59E0B;
    }

    .notification-info .notification-icon {
      background-color: #3B82F6;
    }

    .notification-message {
      flex: 1;
      color: #374151;
    }

    .notification-close {
      background: none;
      border: none;
      font-size: 20px;
      color: #9CA3AF;
      cursor: pointer;
      padding: 0;
      margin-left: 12px;
    }

    .notification-close:hover {
      color: #374151;
    }
  `]
})
export class NotificationComponent implements OnInit {
  notifications: Notification[] = [];

  constructor(private notificationService: NotificationService) {}

  ngOnInit(): void {
    this.notificationService.notifications$.subscribe(notifications => {
      this.notifications = notifications;
    });
  }

  removeNotification(id: string): void {
    this.notificationService.remove(id);
  }
}
