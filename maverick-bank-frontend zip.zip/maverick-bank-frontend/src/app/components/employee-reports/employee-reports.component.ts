import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../services/report.service';
import { NotificationService } from '../../services/notification.service';

interface FinancialPerformanceReport {
  totalAccounts: number;
  totalBalance: number;
  totalTransactions: number;
  totalLoans: number;
  monthlyGrowth: number;
  activeCustomers: number;
  averageAccountBalance: number;
  period: string;
}

interface RegulatoryReport {
  complianceScore: number;
  totalAuditedTransactions: number;
  suspiciousTransactions: number;
  reportDate: string;
  regulatoryStatus: string;
  riskAssessment: string;
}

@Component({
  selector: 'app-employee-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="employee-reports-container">      
      <!-- Header -->
      <div class="reports-header">
        <h2>📊 Employee Reports Dashboard</h2>
        <p>Generate financial performance and regulatory compliance reports</p>
      </div>

      <!-- Report Options -->
      <div class="report-options">
        <!-- Financial Performance Reports -->
        <div class="report-card">
          <div class="report-card-header">
            <div class="report-icon">💰</div>
            <div class="report-info">
              <h3>Financial Performance Reports</h3>
              <p>Comprehensive financial metrics, customer growth, and business performance analysis</p>
            </div>
          </div>
          
          <div class="report-controls">
            <div class="form-group">
              <label for="performancePeriod">Report Period:</label>
              <select id="performancePeriod" [(ngModel)]="selectedPerformancePeriod" class="form-select">
                <option value="current">Current Month</option>
                <option value="quarter">Current Quarter</option>
                <option value="year">Current Year</option>
                <option value="ytd">Year to Date</option>
              </select>
            </div>
            
            <div class="action-buttons">
              <button 
                class="btn btn-primary" 
                (click)="generateFinancialReport()" 
                [disabled]="isLoading">
                <span class="btn-icon">📈</span>
                {{ isLoading ? 'Generating...' : 'Generate Report' }}
              </button>
              
              <button 
                class="btn btn-secondary" 
                (click)="exportFinancialReport()" 
                [disabled]="!financialReport || isLoading">
                <span class="btn-icon">📄</span>
                Export PDF
              </button>
            </div>
          </div>
        </div>

        <!-- Regulatory Reports -->
        <div class="report-card">
          <div class="report-card-header">
            <div class="report-icon">📋</div>
            <div class="report-info">
              <h3>Regulatory Reports</h3>
              <p>Compliance monitoring, audit reports, and regulatory submission documents</p>
            </div>
          </div>
          
          <div class="report-controls">
            <div class="form-group">
              <label for="regulatoryType">Report Type:</label>
              <select id="regulatoryType" [(ngModel)]="selectedRegulatoryType" class="form-select">
                <option value="compliance">Compliance Assessment</option>
                <option value="audit">Internal Audit Report</option>
                <option value="risk">Risk Assessment</option>
                <option value="aml">Anti-Money Laundering</option>
              </select>
            </div>
            
            <div class="action-buttons">
              <button 
                class="btn btn-primary" 
                (click)="generateRegulatoryReport()" 
                [disabled]="isLoading">
                <span class="btn-icon">🔍</span>
                {{ isLoading ? 'Analyzing...' : 'Generate Report' }}
              </button>
              
              <button 
                class="btn btn-secondary" 
                (click)="exportRegulatoryReport()" 
                [disabled]="!regulatoryReport || isLoading">
                <span class="btn-icon">📋</span>
                Export Report
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Financial Performance Display -->
      <div class="performance-display" *ngIf="financialReport">
        <div class="performance-header">
          <h3>Financial Performance Report</h3>
          <div class="report-meta">
            <span>Period: {{ financialReport.period }}</span>
            <span>Generated: {{ getCurrentDate() }}</span>
          </div>
        </div>
        
        <div class="performance-metrics">
          <div class="metric-grid">
            <div class="metric-card total-balance">
              <div class="metric-icon">💰</div>
              <div class="metric-content">
                <div class="metric-value">₹{{ financialReport.totalBalance | number:'1.2-2' }}</div>
                <div class="metric-label">Total Balance</div>
              </div>
            </div>
            
            <div class="metric-card total-accounts">
              <div class="metric-icon">🏦</div>
              <div class="metric-content">
                <div class="metric-value">{{ financialReport.totalAccounts }}</div>
                <div class="metric-label">Total Accounts</div>
              </div>
            </div>
            
            <div class="metric-card total-transactions">
              <div class="metric-icon">💳</div>
              <div class="metric-content">
                <div class="metric-value">{{ financialReport.totalTransactions }}</div>
                <div class="metric-label">Total Transactions</div>
              </div>
            </div>
            
            <div class="metric-card total-loans">
              <div class="metric-icon">📋</div>
              <div class="metric-content">
                <div class="metric-value">{{ financialReport.totalLoans }}</div>
                <div class="metric-label">Active Loans</div>
              </div>
            </div>
          </div>
          
          <div class="performance-details">
            <div class="detail-item">
              <span class="detail-label">Active Customers:</span>
              <span class="detail-value">{{ financialReport.activeCustomers }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Average Account Balance:</span>
              <span class="detail-value">₹{{ financialReport.averageAccountBalance | number:'1.2-2' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Monthly Growth:</span>
              <span class="detail-value growth" [class.positive]="financialReport.monthlyGrowth > 0" [class.negative]="financialReport.monthlyGrowth < 0">
                {{ financialReport.monthlyGrowth > 0 ? '+' : '' }}{{ financialReport.monthlyGrowth }}%
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Regulatory Report Display -->
      <div class="regulatory-display" *ngIf="regulatoryReport">
        <div class="regulatory-header">
          <h3>Regulatory Compliance Report</h3>
          <div class="compliance-status" [class]="getComplianceStatusClass()">
            <span class="status-indicator"></span>
            <span>{{ regulatoryReport.regulatoryStatus }}</span>
          </div>
        </div>
        
        <div class="regulatory-content">
          <div class="compliance-score">
            <div class="score-circle">
              <div class="score-value">{{ regulatoryReport.complianceScore }}%</div>
              <div class="score-label">Compliance Score</div>
            </div>
          </div>
          
          <div class="regulatory-metrics">
            <div class="regulatory-item">
              <span class="reg-label">Total Audited Transactions:</span>
              <span class="reg-value">{{ regulatoryReport.totalAuditedTransactions | number }}</span>
            </div>
            <div class="regulatory-item">
              <span class="reg-label">Suspicious Transactions:</span>
              <span class="reg-value alert" *ngIf="regulatoryReport.suspiciousTransactions > 0">
                {{ regulatoryReport.suspiciousTransactions }}
              </span>
              <span class="reg-value safe" *ngIf="regulatoryReport.suspiciousTransactions === 0">
                {{ regulatoryReport.suspiciousTransactions }}
              </span>
            </div>
            <div class="regulatory-item">
              <span class="reg-label">Risk Assessment:</span>
              <span class="reg-value" [class]="getRiskClass()">{{ regulatoryReport.riskAssessment }}</span>
            </div>
            <div class="regulatory-item">
              <span class="reg-label">Report Date:</span>
              <span class="reg-value">{{ formatDate(regulatoryReport.reportDate) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div class="loading-state" *ngIf="isLoading">
        <div class="loading-spinner"></div>
        <p>Generating comprehensive report...</p>
      </div>

      <!-- No Data State -->
      <div class="no-data-state" *ngIf="!isLoading && !financialReport && !regulatoryReport">
        <div class="no-data-icon">📊</div>
        <h3>No Reports Generated</h3>
        <p>Select a report type above to generate financial performance or regulatory compliance reports.</p>
      </div>
    </div>
  `,
  styleUrls: ['./employee-reports.component.css']
})
export class EmployeeReportsComponent implements OnInit {
  financialReport: FinancialPerformanceReport | null = null;
  regulatoryReport: RegulatoryReport | null = null;
  
  selectedPerformancePeriod = 'current';
  selectedRegulatoryType = 'compliance';
  isLoading = false;

  constructor(
    private reportService: ReportService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    // Auto-generate current month financial report
    this.generateFinancialReport();
  }

  generateFinancialReport(): void {
    this.isLoading = true;
    
    // Get all data needed for financial report
    Promise.all([
      this.reportService.getAllAccounts().toPromise(),
      this.reportService.getAllTransactions().toPromise(),
      this.reportService.getAllLoans().toPromise(),
      this.reportService.getTotalBalance().toPromise()
    ]).then(([accounts, transactions, loans, totalBalance]) => {
      const activeAccounts = accounts?.filter(acc => acc.status === 'ACTIVE') || [];
      const recentTransactions = transactions?.filter(t => this.isInSelectedPeriod(t.timestamp)) || [];
      
      this.financialReport = {
        totalAccounts: accounts?.length || 0,
        totalBalance: totalBalance || 0,
        totalTransactions: recentTransactions.length,
        totalLoans: loans?.length || 0,
        monthlyGrowth: this.calculateGrowthRate(accounts || []),
        activeCustomers: this.getUniqueCustomers(activeAccounts).length,
        averageAccountBalance: this.calculateAverageBalance(activeAccounts),
        period: this.getPeriodLabel(this.selectedPerformancePeriod)
      };
      
      this.isLoading = false;
      this.notificationService.success('Financial performance report generated successfully');
    }).catch(error => {
      console.error('Error generating financial report:', error);
      this.isLoading = false;
      this.notificationService.error('Failed to generate financial report');
    });
  }

  generateRegulatoryReport(): void {
    this.isLoading = true;
    
    // Simulate regulatory analysis
    this.reportService.getAllTransactions().subscribe({
      next: (transactions) => {
        const totalTransactions = transactions.length;
        const suspiciousCount = this.identifySuspiciousTransactions(transactions);
        const complianceScore = this.calculateComplianceScore(totalTransactions, suspiciousCount);
        
        this.regulatoryReport = {
          complianceScore: complianceScore,
          totalAuditedTransactions: totalTransactions,
          suspiciousTransactions: suspiciousCount,
          reportDate: new Date().toISOString(),
          regulatoryStatus: this.getComplianceStatus(complianceScore),
          riskAssessment: this.getRiskAssessment(complianceScore, suspiciousCount)
        };
        
        this.isLoading = false;
        this.notificationService.success('Regulatory compliance report generated successfully');
      },
      error: (error) => {
        console.error('Error generating regulatory report:', error);
        this.isLoading = false;
        this.notificationService.error('Failed to generate regulatory report');
      }
    });
  }

  exportFinancialReport(): void {
    if (!this.financialReport) return;
    
    const reportContent = this.generateFinancialReportText();
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `financial-performance-report-${Date.now()}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    this.notificationService.success('Financial report exported successfully');
  }

  exportRegulatoryReport(): void {
    if (!this.regulatoryReport) return;
    
    const reportContent = this.generateRegulatoryReportText();
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `regulatory-compliance-report-${Date.now()}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    this.notificationService.success('Regulatory report exported successfully');
  }

  private isInSelectedPeriod(timestamp: string): boolean {
    const transactionDate = new Date(timestamp);
    const now = new Date();
    
    switch (this.selectedPerformancePeriod) {
      case 'current':
        return transactionDate.getMonth() === now.getMonth() && 
               transactionDate.getFullYear() === now.getFullYear();
      case 'quarter':
        const currentQuarter = Math.floor(now.getMonth() / 3);
        const transactionQuarter = Math.floor(transactionDate.getMonth() / 3);
        return transactionQuarter === currentQuarter && 
               transactionDate.getFullYear() === now.getFullYear();
      case 'year':
        return transactionDate.getFullYear() === now.getFullYear();
      default:
        return true;
    }
  }

  private calculateGrowthRate(accounts: any[]): number {
    // Simulate growth calculation - in real app, compare with previous period
    return Math.random() * 20 - 10; // Random growth between -10% and +10%
  }

  private getUniqueCustomers(accounts: any[]): any[] {
    const uniqueUserIds = [...new Set(accounts.map(acc => acc.userId))];
    return uniqueUserIds;
  }

  private calculateAverageBalance(accounts: any[]): number {
    if (accounts.length === 0) return 0;
    const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
    return totalBalance / accounts.length;
  }

  private identifySuspiciousTransactions(transactions: any[]): number {
    // Simulate suspicious transaction detection
    // In real app, this would use ML models or rule-based detection
    return Math.floor(transactions.length * 0.001); // 0.1% of transactions marked as suspicious
  }

  private calculateComplianceScore(totalTransactions: number, suspiciousCount: number): number {
    const suspiciousRate = suspiciousCount / totalTransactions;
    const baseScore = 100;
    const penalty = suspiciousRate * 1000; // Heavy penalty for suspicious transactions
    return Math.max(70, Math.floor(baseScore - penalty));
  }

  private getComplianceStatus(score: number): string {
    if (score >= 95) return 'Excellent Compliance';
    if (score >= 85) return 'Good Compliance';
    if (score >= 75) return 'Acceptable Compliance';
    return 'Needs Improvement';
  }

  private getRiskAssessment(score: number, suspiciousCount: number): string {
    if (suspiciousCount > 10) return 'High Risk';
    if (score < 80) return 'Medium Risk';
    return 'Low Risk';
  }

  private getPeriodLabel(period: string): string {
    const labels: { [key: string]: string } = {
      'current': 'Current Month',
      'quarter': 'Current Quarter',
      'year': 'Current Year',
      'ytd': 'Year to Date'
    };
    return labels[period] || 'Current Month';
  }

  private generateFinancialReportText(): string {
    if (!this.financialReport) return '';
    
    return `FINANCIAL PERFORMANCE REPORT
===================================

Report Period: ${this.financialReport.period}
Generated On: ${this.getCurrentDate()}

KEY METRICS
-----------
Total Balance: ₹${this.financialReport.totalBalance.toLocaleString()}
Total Accounts: ${this.financialReport.totalAccounts}
Total Transactions: ${this.financialReport.totalTransactions}
Active Loans: ${this.financialReport.totalLoans}
Active Customers: ${this.financialReport.activeCustomers}
Average Account Balance: ₹${this.financialReport.averageAccountBalance.toLocaleString()}
Monthly Growth Rate: ${this.financialReport.monthlyGrowth}%

ANALYSIS
--------
${this.financialReport.monthlyGrowth > 0 ? 'Positive growth trend observed.' : 'Negative growth trend - requires attention.'}
Customer engagement: ${this.financialReport.activeCustomers / this.financialReport.totalAccounts * 100}% of accounts are active.
`;
  }

  private generateRegulatoryReportText(): string {
    if (!this.regulatoryReport) return '';
    
    return `REGULATORY COMPLIANCE REPORT
==============================

Report Type: ${this.selectedRegulatoryType}
Generated On: ${this.formatDate(this.regulatoryReport.reportDate)}

COMPLIANCE OVERVIEW
------------------
Compliance Score: ${this.regulatoryReport.complianceScore}%
Regulatory Status: ${this.regulatoryReport.regulatoryStatus}
Risk Assessment: ${this.regulatoryReport.riskAssessment}

AUDIT DETAILS
-------------
Total Audited Transactions: ${this.regulatoryReport.totalAuditedTransactions.toLocaleString()}
Suspicious Transactions: ${this.regulatoryReport.suspiciousTransactions}
Suspicious Transaction Rate: ${(this.regulatoryReport.suspiciousTransactions / this.regulatoryReport.totalAuditedTransactions * 100).toFixed(3)}%

RECOMMENDATIONS
--------------
${this.regulatoryReport.complianceScore >= 95 ? 'Maintain current compliance standards.' : 'Review and strengthen compliance procedures.'}
${this.regulatoryReport.suspiciousTransactions > 0 ? 'Investigate flagged transactions and update monitoring systems.' : 'No suspicious activities detected.'}
`;
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  getComplianceStatusClass(): string {
    if (!this.regulatoryReport) return '';
    const score = this.regulatoryReport.complianceScore;
    if (score >= 95) return 'excellent';
    if (score >= 85) return 'good';
    if (score >= 75) return 'acceptable';
    return 'poor';
  }

  getRiskClass(): string {
    if (!this.regulatoryReport) return '';
    const risk = this.regulatoryReport.riskAssessment.toLowerCase();
    if (risk.includes('high')) return 'high-risk';
    if (risk.includes('medium')) return 'medium-risk';
    return 'low-risk';
  }
}
