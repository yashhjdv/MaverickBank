import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService, User } from '../../services/auth.service';
import { AccountManagementService } from '../../services/account-management.service';
import { BeneficiaryService, Beneficiary, CreateBeneficiaryRequest } from '../../services/beneficiary.service';
import { BankService, Bank, Branch } from '../../services/bank.service';
import { NotificationService } from '../../services/notification.service';
import { NotificationComponent } from '../notifications/notification.component';

@Component({
  selector: 'app-beneficiaries',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './beneficiaries.component.html',
  styleUrls: ['./beneficiaries.component.css']
})
export class BeneficiariesComponent implements OnInit {
  user: User | null = null;
  beneficiaries: Beneficiary[] = [];
  banks: Bank[] = [];
  branches: Branch[] = [];
  filteredBranches: Branch[] = [];
  
  // Form
  addBeneficiaryForm: FormGroup;
  
  // UI states
  isLoadingBeneficiaries = false;
  isLoadingBanks = false;
  isSubmittingBeneficiary = false;
  showAddForm = false;
  selectedBankName = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private accountService: AccountManagementService,
    private beneficiaryService: BeneficiaryService,
    private bankService: BankService,
    private notificationService: NotificationService
  ) {
    this.addBeneficiaryForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      accountNumber: ['', [Validators.required, Validators.pattern(/^\d{9,18}$/)]],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      ifscCode: ['', [Validators.required, Validators.pattern(/^[A-Z]{4}0[A-Z0-9]{6}$/)]]
    });
  }

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      if (user) {
        this.loadBeneficiaries();
        this.loadBanks();
      }
    });

    // Watch for bank selection changes
    this.addBeneficiaryForm.get('bankName')?.valueChanges.subscribe(bankName => {
      if (bankName) {
        this.selectedBankName = bankName;
        this.loadBranchesForBank(bankName);
        // Reset branch and IFSC when bank changes
        this.addBeneficiaryForm.patchValue({
          branchName: '',
          ifscCode: ''
        });
      }
    });

    // Watch for branch selection changes
    this.addBeneficiaryForm.get('branchName')?.valueChanges.subscribe(branchName => {
      if (branchName) {
        const selectedBranch = this.filteredBranches.find(branch => branch.name === branchName);
        if (selectedBranch) {
          this.addBeneficiaryForm.patchValue({
            ifscCode: selectedBranch.ifscCode
          });
        }
      }
    });
  }

  loadBeneficiaries(): void {
    if (!this.user?.id) return;
    
    this.isLoadingBeneficiaries = true;
    this.beneficiaryService.getUserBeneficiaries(this.user.id).subscribe({
      next: (beneficiaries: Beneficiary[]) => {
        this.beneficiaries = beneficiaries;
        this.isLoadingBeneficiaries = false;
      },
      error: (error: any) => {
        console.error('Error loading beneficiaries:', error);
        this.isLoadingBeneficiaries = false;
        // Use mock data for development
        this.beneficiaries = this.getMockBeneficiaries();
        console.warn('Using mock beneficiaries data');
      }
    });
  }

  loadBanks(): void {
    this.isLoadingBanks = true;
    this.bankService.getAllBanks().subscribe({
      next: (banks: Bank[]) => {
        this.banks = banks;
        this.isLoadingBanks = false;
      },
      error: (error: any) => {
        console.error('Error loading banks:', error);
        this.isLoadingBanks = false;
        // Use mock data for development
        this.banks = this.getMockBanks();
        console.warn('Using mock banks data');
      }
    });
  }

  loadBranchesForBank(bankName: string): void {
    this.bankService.getBranchesByBankName(bankName).subscribe({
      next: (branches: Branch[]) => {
        this.filteredBranches = branches;
      },
      error: (error: any) => {
        console.error('Error loading branches:', error);
        // Use mock data for development
        this.filteredBranches = this.getMockBranches().filter(branch => branch.bankName === bankName);
        console.warn('Using mock branches data');
      }
    });
  }

  toggleAddForm(): void {
    this.showAddForm = !this.showAddForm;
    if (!this.showAddForm) {
      this.addBeneficiaryForm.reset();
    }
  }

  onSubmitBeneficiary(): void {
    if (this.addBeneficiaryForm.valid && this.user?.id) {
      this.isSubmittingBeneficiary = true;
      
      const formValue = this.addBeneficiaryForm.value;
      const request: CreateBeneficiaryRequest = {
        ...formValue,
        userId: this.user.id
      };

      this.beneficiaryService.addBeneficiary(request).subscribe({
        next: (beneficiary: Beneficiary) => {
          this.isSubmittingBeneficiary = false;
          this.notificationService.success('Beneficiary added successfully!');
          this.beneficiaries.push(beneficiary);
          this.toggleAddForm();
        },
        error: (error: any) => {
          this.isSubmittingBeneficiary = false;
          console.error('Error adding beneficiary:', error);
          this.notificationService.error('Failed to add beneficiary. Please try again.');
        }
      });
    }
  }

  onDeleteBeneficiary(beneficiary: Beneficiary): void {
    if (confirm(`Are you sure you want to remove ${beneficiary.name} from your beneficiaries?`)) {
      this.beneficiaryService.deleteBeneficiary(beneficiary.id).subscribe({
        next: () => {
          this.notificationService.success('Beneficiary removed successfully');
          this.loadBeneficiaries(); // Reload the list
        },
        error: (error) => {
          this.notificationService.error('Failed to remove beneficiary: ' + error.message);
        }
      });
    }
  }

  onEditBeneficiary(beneficiary: Beneficiary): void {
    // TODO: Implement edit functionality
    this.notificationService.info('Edit functionality will be implemented soon');
  }

  onTransferToBeneficiary(beneficiary: Beneficiary): void {
    // TODO: Navigate to transfer page with beneficiary pre-selected
    this.notificationService.info(`Transfer to ${beneficiary.name} - Coming soon!`);
  }

  // Utility methods
  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('en-IN');
  }

  // Form validation helpers
  isFieldInvalid(fieldName: string): boolean {
    const field = this.addBeneficiaryForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.addBeneficiaryForm.get(fieldName);
    if (field && field.errors && field.touched) {
      if (field.errors['required']) {
        return `${fieldName.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
      }
      if (field.errors['minlength']) {
        return `${fieldName.replace(/([A-Z])/g, ' $1').toLowerCase()} must be at least ${field.errors['minlength'].requiredLength} characters`;
      }
      if (field.errors['pattern']) {
        if (fieldName === 'accountNumber') {
          return 'Account number must be 9-18 digits';
        }
        if (fieldName === 'ifscCode') {
          return 'Invalid IFSC code format (e.g., ABCD0123456)';
        }
      }
    }
    return '';
  }

  // Mock data for development
  private getMockBeneficiaries(): Beneficiary[] {
    return [
      {
        id: 1,
        name: 'John Doe',
        accountNumber: '1234567890123',
        bankName: 'State Bank of India',
        branchName: 'Main Branch',
        ifscCode: 'SBIN0001001',
        addedDate: new Date('2024-01-10'),
        userId: this.user?.id || 1,
        isActive: true
      },
      {
        id: 2,
        name: 'Jane Smith',
        accountNumber: '9876543210987',
        bankName: 'HDFC Bank',
        branchName: 'City Center Branch',
        ifscCode: 'HDFC0001234',
        addedDate: new Date('2024-01-05'),
        userId: this.user?.id || 1,
        isActive: true
      }
    ];
  }

  private getMockBanks(): Bank[] {
    return [
      { id: 1, name: 'State Bank of India', code: 'SBI' },
      { id: 2, name: 'HDFC Bank', code: 'HDFC' },
      { id: 3, name: 'ICICI Bank', code: 'ICICI' },
      { id: 4, name: 'Axis Bank', code: 'AXIS' },
      { id: 5, name: 'Punjab National Bank', code: 'PNB' }
    ];
  }

  private getMockBranches(): Branch[] {
    return [
      {
        id: 1,
        name: 'Main Branch',
        address: '123 Main Street, Delhi',
        ifscCode: 'SBIN0001001',
        bankName: 'State Bank of India'
      },
      {
        id: 2,
        name: 'Connaught Place Branch',
        address: 'CP, New Delhi',
        ifscCode: 'SBIN0001002',
        bankName: 'State Bank of India'
      },
      {
        id: 3,
        name: 'City Center Branch',
        address: '456 Business District, Mumbai',
        ifscCode: 'HDFC0001234',
        bankName: 'HDFC Bank'
      },
      {
        id: 4,
        name: 'Airport Branch',
        address: 'Airport Road, Mumbai',
        ifscCode: 'HDFC0001235',
        bankName: 'HDFC Bank'
      }
    ];
  }
}
