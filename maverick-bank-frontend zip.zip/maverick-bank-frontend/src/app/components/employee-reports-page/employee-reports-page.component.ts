import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeReportsComponent } from '../employee-reports/employee-reports.component';

@Component({
  selector: 'app-employee-reports-page',
  standalone: true,
  imports: [CommonModule, EmployeeReportsComponent],
  template: `
    <div class="reports-page">
      <div class="page-header">
        <h1>📊 Employee Reports Dashboard</h1>
        <p>Generate financial performance reports and regulatory compliance reports</p>
      </div>
      
      <div class="reports-content">
        <app-employee-reports></app-employee-reports>
      </div>
    </div>
  `,
  styles: [`
    .reports-page {
      padding: 20px;
      max-width: 1400px;
      margin: 0 auto;
      background: #f8f9fa;
      min-height: 100vh;
    }

    .page-header {
      text-align: center;
      margin-bottom: 32px;
      padding: 24px;
      background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
      border-radius: 16px;
      color: white;
      box-shadow: 0 8px 32px rgba(30, 60, 114, 0.3);
    }

    .page-header h1 {
      margin: 0 0 8px 0;
      font-size: 2.5rem;
      font-weight: 700;
    }

    .page-header p {
      margin: 0;
      font-size: 1.125rem;
      opacity: 0.9;
    }

    .reports-content {
      background: white;
      border-radius: 16px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
  `]
})
export class EmployeeReportsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
