import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LoanService, Loan, LoanType, LoanApplicationRequest, EMICalculationRequest } from '../../services/loan.service';
import { AccountManagementService } from '../../services/account-management.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-loan-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './loan-management.component.html',
  styleUrls: ['./loan-management.component.css']
})
export class LoanManagementComponent implements OnInit {
  userRole: string = 'CUSTOMER';
  
  loans: Loan[] = [];
  loanTypes: LoanType[] = [];
  userAccounts: any[] = [];
  currentUser: any;
  
  // UI States
  showLoanApplication = false;
  showEMICalculator = false;
  isLoading = false;
  isSubmittingApplication = false;
  isCalculatingEMI = false;
  
  // Forms
  loanApplicationForm!: FormGroup;
  emiCalculatorForm!: FormGroup;
  
  // Calculated EMI Data
  calculatedEMI: any = null;
  eligibilityResult: any = null;
  
  // Employee specific
  pendingLoans: Loan[] = [];
  selectedLoan: Loan | null = null;
  employeeComments = '';

  constructor(
    private fb: FormBuilder,
    private loanService: LoanService,
    private accountService: AccountManagementService,
    private authService: AuthService,
    private router: Router
  ) {
    this.initializeForms();
  }

  ngOnInit(): void {
    this.loadCurrentUser();
    this.loadLoanTypes();
    
    // Set user role from auth service
    const user = this.authService.getCurrentUser();
    if (user && user.roles && user.roles.length > 0) {
      // Extract the role name from the role object
      const roleObj = user.roles[0];
      this.userRole = roleObj.name || roleObj; // Use role.name if it's an object, otherwise use the role directly
    }
    
    console.log('Loan Management - User Role:', this.userRole);
    console.log('Loan Management - Current User:', this.currentUser);
    
    if (this.userRole === 'CUSTOMER') {
      this.loadUserLoans();
      this.loadUserAccounts();
    } else if (this.userRole === 'EMPLOYEE') {
      this.loadPendingLoans();
    }
  }

  private initializeForms(): void {
    this.loanApplicationForm = this.fb.group({
      loanTypeId: ['', Validators.required],
      accountId: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1000)]],
      tenure: ['', [Validators.required, Validators.min(1), Validators.max(30)]],
      purpose: ['', Validators.required],
      monthlyIncome: ['', [Validators.required, Validators.min(10000)]],
      employmentType: ['', Validators.required],
      existingEmis: [0, [Validators.min(0)]]
    });

    this.emiCalculatorForm = this.fb.group({
      principal: ['', [Validators.required, Validators.min(1000)]],
      interestRate: ['', [Validators.required, Validators.min(1), Validators.max(30)]],
      tenure: ['', [Validators.required, Validators.min(1), Validators.max(30)]]
    });
  }

  private loadCurrentUser(): void {
    this.currentUser = this.authService.getCurrentUser();
    console.log('Loaded current user:', this.currentUser);
    
    if (!this.currentUser) {
      console.error('No current user found, redirecting to login');
      this.router.navigate(['/']);
    }
  }

  private loadUserLoans(): void {
    if (!this.currentUser?.id) {
      console.error('Cannot load user loans: No user ID available');
      return;
    }
    
    this.isLoading = true;
    console.log('Loading loans for user ID:', this.currentUser.id);
    
    this.loanService.getUserLoans(this.currentUser.id).subscribe({
      next: (loans) => {
        console.log('Loaded loans:', loans);
        this.loans = loans;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading loans:', error);
        this.loans = []; // Set empty array as fallback
        this.isLoading = false;
      }
    });
  }

  private loadLoanTypes(): void {
    console.log('Loading loan types...');
    this.loanService.getAllActiveLoanTypes().subscribe({
      next: (types) => {
        console.log('Loaded loan types:', types);
        this.loanTypes = types;
      },
      error: (error) => {
        console.error('Error loading loan types:', error);
        this.loanTypes = []; // Set empty array as fallback
      }
    });
  }

  private loadUserAccounts(): void {
    if (!this.currentUser?.id) return;
    
    this.accountService.getUserAccounts(this.currentUser.id).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts;
      },
      error: (error) => {
        console.error('Error loading accounts:', error);
      }
    });
  }

  private loadPendingLoans(): void {
    this.isLoading = true;
    console.log('Loading pending loans...');
    
    this.loanService.getPendingLoans().subscribe({
      next: (loans) => {
        console.log('Loaded pending loans:', loans);
        this.pendingLoans = loans;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading pending loans:', error);
        this.pendingLoans = []; // Set empty array as fallback
        this.isLoading = false;
      }
    });
  }

  // Customer Methods
  toggleLoanApplication(): void {
    this.showLoanApplication = !this.showLoanApplication;
    if (!this.showLoanApplication) {
      this.loanApplicationForm.reset();
      this.eligibilityResult = null;
    }
  }

  toggleEMICalculator(): void {
    this.showEMICalculator = !this.showEMICalculator;
    if (!this.showEMICalculator) {
      this.emiCalculatorForm.reset();
      this.calculatedEMI = null;
    }
  }

  onLoanTypeChange(): void {
    const loanTypeId = this.loanApplicationForm.get('loanTypeId')?.value;
    const selectedType = this.loanTypes.find(type => type.id === parseInt(loanTypeId));
    
    if (selectedType) {
      // Update form validators based on loan type limits
      this.loanApplicationForm.get('amount')?.setValidators([
        Validators.required,
        Validators.min(selectedType.minAmount),
        Validators.max(selectedType.maxAmount)
      ]);
      
      this.loanApplicationForm.get('tenure')?.setValidators([
        Validators.required,
        Validators.min(selectedType.minTenure),
        Validators.max(selectedType.maxTenure)
      ]);
      
      // Update EMI calculator
      this.emiCalculatorForm.get('interestRate')?.setValue(selectedType.interestRate);
    }
  }

  calculateEMI(): void {
    if (this.emiCalculatorForm.valid) {
      this.isCalculatingEMI = true;
      const request: EMICalculationRequest = this.emiCalculatorForm.value;
      
      this.loanService.calculateEMI(request).subscribe({
        next: (result) => {
          this.calculatedEMI = result;
          this.isCalculatingEMI = false;
        },
        error: (error) => {
          console.error('Error calculating EMI:', error);
          this.isCalculatingEMI = false;
        }
      });
    }
  }

  checkEligibility(): void {
    if (this.loanApplicationForm.valid && this.currentUser?.id) {
      const request = {
        userId: this.currentUser.id,
        loanTypeId: this.loanApplicationForm.get('loanTypeId')?.value,
        amount: this.loanApplicationForm.get('amount')?.value,
        monthlyIncome: this.loanApplicationForm.get('monthlyIncome')?.value,
        existingEmis: this.loanApplicationForm.get('existingEmis')?.value || 0
      };
      
      this.loanService.checkEligibility(request).subscribe({
        next: (result) => {
          this.eligibilityResult = result;
        },
        error: (error) => {
          console.error('Error checking eligibility:', error);
        }
      });
    }
  }

  submitLoanApplication(): void {
    if (this.loanApplicationForm.valid && this.currentUser?.id) {
      this.isSubmittingApplication = true;
      
      const request: LoanApplicationRequest = {
        ...this.loanApplicationForm.value,
        userId: this.currentUser.id
      };
      
      this.loanService.applyForLoan(request).subscribe({
        next: (loan) => {
          console.log('Loan application submitted:', loan);
          this.loadUserLoans(); // Refresh loans
          this.toggleLoanApplication();
          this.isSubmittingApplication = false;
          alert('Loan application submitted successfully!');
        },
        error: (error) => {
          console.error('Error submitting loan application:', error);
          this.isSubmittingApplication = false;
          alert('Error submitting loan application. Please try again.');
        }
      });
    }
  }

  // Employee Methods
  selectLoanForReview(loan: Loan): void {
    this.selectedLoan = loan;
    this.employeeComments = '';
  }

  approveLoan(loan: Loan): void {
    if (!this.currentUser?.id) return;
    
    const comments = this.employeeComments || 'Loan approved by employee';
    this.loanService.approveLoan(loan.id, comments, this.currentUser.id).subscribe({
      next: (updatedLoan) => {
        console.log('Loan approved:', updatedLoan);
        this.loadPendingLoans(); // Refresh pending loans
        this.selectedLoan = null;
        alert('Loan approved successfully!');
      },
      error: (error) => {
        console.error('Error approving loan:', error);
        alert('Error approving loan. Please try again.');
      }
    });
  }

  rejectLoan(loan: Loan): void {
    if (!this.currentUser?.id) return;
    
    const comments = this.employeeComments || 'Loan rejected by employee';
    this.loanService.rejectLoan(loan.id, comments, this.currentUser.id).subscribe({
      next: (updatedLoan) => {
        console.log('Loan rejected:', updatedLoan);
        this.loadPendingLoans(); // Refresh pending loans
        this.selectedLoan = null;
        alert('Loan rejected successfully!');
      },
      error: (error) => {
        console.error('Error rejecting loan:', error);
        alert('Error rejecting loan. Please try again.');
      }
    });
  }

  disburseLoan(loan: Loan): void {
    if (!this.currentUser?.id) return;
    
    this.loanService.disburseLoan(loan.id, this.currentUser.id).subscribe({
      next: (updatedLoan) => {
        console.log('Loan disbursed:', updatedLoan);
        this.loadPendingLoans(); // Refresh pending loans
        alert('Loan disbursed successfully!');
      },
      error: (error) => {
        console.error('Error disbursing loan:', error);
        alert('Error disbursing loan. Please try again.');
      }
    });
  }

  // Utility Methods
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('en-IN');
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'APPROVED': return 'status-approved';
      case 'REJECTED': return 'status-rejected';
      case 'DISBURSED': return 'status-disbursed';
      case 'CLOSED': return 'status-closed';
      default: return 'status-pending';
    }
  }

  getSelectedLoanType(): LoanType | null {
    const loanTypeId = this.loanApplicationForm.get('loanTypeId')?.value;
    return this.loanTypes.find(type => type.id === parseInt(loanTypeId)) || null;
  }

  // Navigation method
  navigateToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }
}
